const nameElement = document.getElementById("animatedName");
const words = ["I", "I am", "I am Ajeet", "I am Ajeet Vishwakarma"];
let wordIndex = 0;

function animateName() {
  nameElement.textContent = words[wordIndex];
  wordIndex++;

  if (wordIndex >= words.length) {
    setTimeout(() => {
      wordIndex = 0;
      animateName();
    }, 2200);
  } else {
    setTimeout(animateName, 800);
  }
}

animateName();

document.getElementById("startBtn").addEventListener("click", () => {
  alert("Video Editor module Part 2 will be added here.");
});

document.getElementById("projectsBtn").addEventListener("click", () => {
  alert("My Projects section will be added here.");
});

const modal = document.getElementById("settingsModal");

document.getElementById("settingsBtn").addEventListener("click", () => {
  modal.classList.remove("hidden");
});

document.getElementById("closeSettings").addEventListener("click", () => {
  modal.classList.add("hidden");
});

modal.addEventListener("click", (event) => {
  if (event.target === modal) {
    modal.classList.add("hidden");
  }
});

document.getElementById("darkMode").addEventListener("change", (event) => {
  if (!event.target.checked) {
    document.documentElement.style.setProperty("--bg", "#f4f4f7");
    document.documentElement.style.setProperty("--panel", "#ffffff");
    document.documentElement.style.setProperty("--panel2", "#eeeeF3");
    document.documentElement.style.setProperty("--text", "#15151b");
    document.documentElement.style.setProperty("--muted", "#555563");
  } else {
    document.documentElement.style.setProperty("--bg", "#08080d");
    document.documentElement.style.setProperty("--panel", "#111118");
    document.documentElement.style.setProperty("--panel2", "#171720");
    document.documentElement.style.setProperty("--text", "#f7f7fb");
    document.documentElement.style.setProperty("--muted", "#a6a6b4");
  }
});
