// LearnHub - Chapter 1

const themeButton = document.getElementById("themeButton");
const startButton = document.getElementById("startButton");

const savedTheme = localStorage.getItem("learnhub-theme");

if (savedTheme === "light") {
    document.body.classList.add("light");
    themeButton.textContent = "🌙";
}

themeButton.addEventListener("click", () => {
    document.body.classList.toggle("light");

    const isLight = document.body.classList.contains("light");

    if (isLight) {
        themeButton.textContent = "🌙";
        localStorage.setItem("learnhub-theme", "light");
    } else {
        themeButton.textContent = "☀️";
        localStorage.setItem("learnhub-theme", "dark");
    }
});

startButton.addEventListener("click", () => {
    alert("LearnHub is ready!\n\nChapter 2 में Home Page और tools आगे add होंगे.");
});

document.querySelectorAll(".nav-item").forEach((button) => {
    button.addEventListener("click", () => {
        document.querySelectorAll(".nav-item").forEach((item) => {
            item.classList.remove("active");
        });

        button.classList.add("active");
    });
});

console.log("LearnHub Chapter 1 loaded successfully.");
