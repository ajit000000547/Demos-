/* NEXORA content. To add content, just add objects to these arrays – no app code changes needed. */
const NEXORA_DATA = {
  categories: [
    {
      id: 'web', title: 'Web Development', icon: '💻',
      description: 'Build web pages with HTML and CSS, step by step.',
      chapters: [
        {
          id: 'html-basics', title: 'HTML Basics',
          description: 'Learn how web pages are structured using tags and attributes.',
          objectives: ['Explain what HTML is', 'Write headings, paragraphs and lists', 'Add links and images correctly'],
          topics: [
            { id: 'what-is-html', title: 'What is HTML?',
              content: '<p>HTML (HyperText Markup Language) describes the structure of a web page. Browsers read HTML and turn it into headings, text, images and buttons.</p><p>Every page has a <code>&lt;head&gt;</code> for settings and a <code>&lt;body&gt;</code> for visible content.</p>',
              example: '&lt;h1&gt;Hello NEXORA&lt;/h1&gt;\n&lt;p&gt;My first page.&lt;/p&gt;' },
            { id: 'tags-attributes', title: 'Tags and Attributes',
              content: '<p>Most elements have an opening tag and a closing tag, like <code>&lt;p&gt;…&lt;/p&gt;</code>. Attributes add extra information inside the opening tag, such as <code>class</code> or <code>id</code>.</p><ul><li><code>&lt;h1&gt;</code> to <code>&lt;h6&gt;</code>: headings (h1 is the largest)</li><li><code>&lt;p&gt;</code>: paragraph</li><li><code>&lt;ul&gt;</code> and <code>&lt;li&gt;</code>: bullet list</li></ul>',
              example: '&lt;p class="intro"&gt;Welcome!&lt;/p&gt;' },
            { id: 'links-images', title: 'Links and Images',
              content: '<p>Use <code>&lt;a href="…"&gt;</code> to link to another page. Use <code>&lt;img src="…" alt="…"&gt;</code> to show a picture. The <code>alt</code> text describes the image for screen readers and shows if the image fails to load.</p>',
              example: '&lt;a href="about.html"&gt;About us&lt;/a&gt;\n&lt;img src="logo.png" alt="NEXORA logo"&gt;' }
          ],
          practice: [
            { q: 'Which tag creates the largest heading?', options: ['<h6>', '<h1>', '<head>', '<title>'], answer: 1, explain: '<h1> is the top-level and largest heading.' },
            { q: 'Which attribute gives a link its destination?', options: ['src', 'href', 'alt', 'link'], answer: 1, explain: 'href holds the URL a link points to.' },
            { q: 'What does the alt attribute on an image provide?', options: ['Image size', 'Alternative text', 'Border style', 'Link target'], answer: 1, explain: 'alt is text shown or read aloud when the image cannot be seen.' }
          ]
        },
        {
          id: 'css-basics', title: 'CSS Basics',
          description: 'Style your pages with selectors, spacing and flexible layouts.',
          objectives: ['Select elements with CSS selectors', 'Understand the box model', 'Build a simple layout with Flexbox'],
          topics: [
            { id: 'selectors', title: 'Selectors',
              content: '<p>A selector chooses which elements a rule applies to. An element selector uses the tag name (<code>p</code>), a class selector starts with a dot (<code>.card</code>) and an id selector starts with a hash (<code>#menu</code>).</p>',
              example: '.card { color: teal; }\np { line-height: 1.6; }' },
            { id: 'box-model', title: 'The Box Model',
              content: '<p>Every element is a box made of four layers, from inside to outside: <b>content</b>, <b>padding</b>, <b>border</b> and <b>margin</b>. Padding adds space inside the border; margin adds space outside it.</p>',
              example: '.box { padding: 16px; border: 2px solid #333; margin: 12px; }' },
            { id: 'flexbox', title: 'Flexbox Basics',
              content: '<p>Set <code>display: flex</code> on a parent to lay its children in a row. <code>justify-content</code> spaces items along the main axis and <code>align-items</code> aligns them on the cross axis.</p>',
              example: '.row { display: flex; gap: 12px; justify-content: space-between; }' }
          ],
          practice: [
            { q: 'Which selector targets elements with class "card"?', options: ['#card', '.card', 'card', '*card'], answer: 1, explain: 'A dot selects by class name.' },
            { q: 'In the box model, which layer is outermost?', options: ['Content', 'Padding', 'Border', 'Margin'], answer: 3, explain: 'Margin sits outside the border.' },
            { q: 'Which declaration makes an element a flex container?', options: ['display: flex', 'flex: container', 'position: flex', 'layout: flex'], answer: 0, explain: 'display: flex turns on Flexbox layout for the children.' }
          ]
        }
      ],
      quizzes: [
        { id: 'web-quiz', title: 'Web Fundamentals Quiz', description: 'Mixed questions from HTML and CSS.', seconds: 120,
          questions: [
            { q: 'HTML stands for…', options: ['HyperText Markup Language', 'High Tech Modern Language', 'Hyper Transfer Markup Logic', 'Home Tool Markup Language'], answer: 0, explain: 'HyperText Markup Language.' },
            { q: 'Which CSS property changes text colour?', options: ['font-color', 'text-style', 'color', 'foreground'], answer: 2, explain: 'The color property sets text colour.' },
            { q: 'Which tag defines a paragraph?', options: ['<p>', '<para>', '<pg>', '<text>'], answer: 0, explain: '<p> is the paragraph element.' },
            { q: 'What does justify-content do in Flexbox?', options: ['Aligns items along the main axis', 'Sets the font', 'Adds a border', 'Changes z-index'], answer: 0, explain: 'It distributes items along the main axis.' }
          ] }
      ]
    },
    {
      id: 'math', title: 'Everyday Mathematics', icon: '🧮',
      description: 'Percentages and algebra you can use in daily life.',
      chapters: [
        {
          id: 'percentages', title: 'Percentages',
          description: 'Work with percentages for shopping, marks and growth.',
          objectives: ['Understand what percent means', 'Find a percentage of a number', 'Calculate discounts and increases'],
          topics: [
            { id: 'understanding-percent', title: 'Understanding Percent',
              content: '<p>Percent means "out of 100". So 50% = 50/100 = 1/2 = 0.5. To convert a percent to a decimal, divide by 100.</p>',
              example: '25% = 25 ÷ 100 = 0.25' },
            { id: 'percent-of-number', title: 'Percentage of a Number',
              content: '<p>To find a percentage of a number, convert the percent to a decimal and multiply.</p>',
              example: '20% of 150 = 0.20 × 150 = 30' },
            { id: 'discounts', title: 'Discounts and Increases',
              content: '<p>A discount reduces the price: <b>saving = price × percent ÷ 100</b>. Percent increase is <b>(new − old) ÷ old × 100</b>.</p>',
              example: '₹800 with 25% off → saving ₹200, pay ₹600' }
          ],
          practice: [
            { q: 'What is 25% of 200?', options: ['25', '50', '75', '100'], answer: 1, explain: '0.25 × 200 = 50.' },
            { q: 'What is 50% written as a fraction?', options: ['1/4', '1/3', '1/2', '2/3'], answer: 2, explain: '50/100 simplifies to 1/2.' },
            { q: 'A 20% discount on ₹500 saves how much?', options: ['₹20', '₹50', '₹100', '₹200'], answer: 2, explain: '0.20 × 500 = 100.' }
          ]
        },
        {
          id: 'algebra-basics', title: 'Algebra Basics',
          description: 'Use letters for unknown numbers and solve simple equations.',
          objectives: ['Read variables and expressions', 'Combine like terms', 'Solve one-step equations'],
          topics: [
            { id: 'variables', title: 'Variables and Expressions',
              content: '<p>A variable is a letter, like <b>x</b>, that stands for a number. Like terms can be added together: 2x + 3x = 5x.</p>',
              example: '4y + y = 5y' },
            { id: 'simple-equations', title: 'Solving Simple Equations',
              content: '<p>To solve an equation, do the same operation on both sides until the variable is alone.</p>',
              example: 'x + 7 = 12 → x = 12 − 7 → x = 5\n3x = 18 → x = 18 ÷ 3 → x = 6' }
          ],
          practice: [
            { q: 'Solve: x + 7 = 12', options: ['3', '5', '7', '19'], answer: 1, explain: 'Subtract 7 from both sides: x = 5.' },
            { q: 'Solve: 3x = 18', options: ['3', '6', '9', '15'], answer: 1, explain: 'Divide both sides by 3: x = 6.' },
            { q: 'Simplify: 2x + 3x', options: ['5x', '6x', '5x²', 'x⁵'], answer: 0, explain: 'Add the coefficients: 2 + 3 = 5.' }
          ]
        }
      ],
      quizzes: [
        { id: 'math-quiz', title: 'Numbers Quiz', description: 'Percentages and algebra together.', seconds: 120,
          questions: [
            { q: 'What is 10% of 350?', options: ['30', '35', '3.5', '45'], answer: 1, explain: '0.10 × 350 = 35.' },
            { q: 'If 2x − 4 = 10, what is x?', options: ['3', '6', '7', '14'], answer: 2, explain: '2x = 14, so x = 7.' },
            { q: 'A price rises from 50 to 60. What is the percent increase?', options: ['10%', '20%', '25%', '50%'], answer: 1, explain: '(60 − 50) ÷ 50 = 0.20 = 20%.' },
            { q: 'Which value equals 0.75?', options: ['3/4', '2/3', '1/4', '4/5'], answer: 0, explain: '3 ÷ 4 = 0.75.' }
          ] }
      ]
    },
    {
      id: 'science', title: 'General Science', icon: '🔬',
      description: 'Space and the human body explained simply.',
      chapters: [
        {
          id: 'solar-system', title: 'Our Solar System',
          description: 'Meet the Sun, the planets and the Moon.',
          objectives: ['Name the planets in order', 'Compare inner and outer planets', 'Explain how the Moon causes tides'],
          topics: [
            { id: 'sun-planets', title: 'The Sun and Planets',
              content: '<p>The Sun is a star at the centre of our solar system. Eight planets orbit it, in order: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus and Neptune.</p>',
              example: 'Closest to the Sun: Mercury. Largest planet: Jupiter.' },
            { id: 'inner-outer', title: 'Inner vs Outer Planets',
              content: '<p>The four inner planets are small and rocky. The four outer planets are much larger: Jupiter and Saturn are gas giants, Uranus and Neptune are ice giants.</p>',
              example: 'Mars is called the Red Planet because of iron oxide (rust) on its surface.' },
            { id: 'moon-tides', title: 'The Moon and Tides',
              content: '<p>The Moon is Earth\'s natural satellite. Its gravity pulls on the oceans, creating high and low tides about twice a day.</p>',
              example: 'Tides are strongest when the Sun, Earth and Moon line up.' }
          ],
          practice: [
            { q: 'Which planet is closest to the Sun?', options: ['Venus', 'Earth', 'Mercury', 'Mars'], answer: 2, explain: 'Mercury orbits closest to the Sun.' },
            { q: 'Which is the largest planet?', options: ['Saturn', 'Jupiter', 'Neptune', 'Earth'], answer: 1, explain: 'Jupiter is the largest planet.' },
            { q: 'What mainly causes ocean tides?', options: ['Wind', "The Moon's gravity", 'Rain', 'Volcanoes'], answer: 1, explain: "The Moon's gravity pulls the oceans." }
          ]
        },
        {
          id: 'human-body', title: 'Human Body Basics',
          description: 'How the heart and digestive system keep you going.',
          objectives: ['Describe the heart and circulation', 'Explain how digestion works'],
          topics: [
            { id: 'heart', title: 'The Heart and Circulation',
              content: '<p>The heart is a muscle with four chambers that pumps blood around the body. Arteries carry blood away from the heart; veins carry it back.</p>',
              example: 'A resting adult heart beats about 60–100 times per minute.' },
            { id: 'digestion', title: 'The Digestive System',
              content: '<p>Food is broken down in the mouth and stomach. The small intestine absorbs most nutrients into the blood; the large intestine absorbs water.</p>',
              example: 'Path of food: mouth → oesophagus → stomach → small intestine → large intestine.' }
          ],
          practice: [
            { q: 'How many chambers does the human heart have?', options: ['2', '3', '4', '5'], answer: 2, explain: 'Two atria and two ventricles.' },
            { q: 'Where does most nutrient absorption happen?', options: ['Stomach', 'Small intestine', 'Large intestine', 'Oesophagus'], answer: 1, explain: 'The small intestine absorbs most nutrients.' },
            { q: 'Which vessels carry blood away from the heart?', options: ['Veins', 'Arteries', 'Capillaries', 'Nerves'], answer: 1, explain: 'Arteries carry blood away from the heart.' }
          ]
        }
      ],
      quizzes: [
        { id: 'science-quiz', title: 'Science Mix Quiz', description: 'Space and body questions.', seconds: 120,
          questions: [
            { q: 'Which planet is known as the Red Planet?', options: ['Mars', 'Venus', 'Jupiter', 'Mercury'], answer: 0, explain: 'Mars looks red because of iron oxide.' },
            { q: 'Which organ pumps blood?', options: ['Lungs', 'Liver', 'Heart', 'Kidney'], answer: 2, explain: 'The heart pumps blood.' },
            { q: "What is Earth's natural satellite?", options: ['Moon', 'Phobos', 'Titan', 'Europa'], answer: 0, explain: 'The Moon orbits Earth.' },
            { q: 'Which gas do we need to breathe in?', options: ['Nitrogen', 'Oxygen', 'Helium', 'Hydrogen'], answer: 1, explain: 'Our bodies use oxygen.' }
          ] }
      ]
    }
  ],
  tools: [
    { id: 'calculator', title: 'Calculator', icon: '🧮', description: 'Add, subtract, multiply, divide and percent.' },
    { id: 'timer', title: 'Timer', icon: '⏳', description: 'Countdown with start, pause and reset.' },
    { id: 'stopwatch', title: 'Stopwatch', icon: '⏱️', description: 'Measure time with laps.' },
    { id: 'notes', title: 'Notes', icon: '📝', description: 'Write, edit and delete notes saved on this device.' }
  ],
  games: [
    { id: 'memory', title: 'Memory Match', icon: '🧠', bestMode: 'low', unit: 'moves',
      description: 'Flip cards and find all matching pairs.',
      instructions: 'Tap two cards to flip them. If they match they stay open. Find all 6 pairs using as few moves as you can.' },
    { id: 'quicktap', title: 'Quick Tap', icon: '🎯', bestMode: 'high', unit: 'points',
      description: 'Tap the target as many times as you can in 30 seconds.',
      instructions: 'Press Start, then tap the glowing target every time it moves. You have 30 seconds. Each hit is 1 point.' }
  ]
};
