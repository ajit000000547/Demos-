/* NEXORA app: routing, views, search, settings, PWA */
(function () {
  'use strict';
  const D = NEXORA_DATA, { $, $$, esc, Store: S, toast, modal, closeModal, confirmBox } = NX;
  const view = $('#view');
  const NAV = [['home', 'Home', '🏠'], ['explore', 'Explore', '🧭'], ['categories', 'Categories', '🗂️'], ['tools', 'Tools', '🧰'], ['games', 'Games', '🎮'], ['settings', 'Settings', '⚙️']];
  const PARENT = { category: 'categories', chapter: 'categories', topic: 'categories', practice: 'categories', quiz: 'categories', tool: 'tools', game: 'games', progress: 'home' };

  /* ---------- helpers ---------- */
  const cat = id => D.categories.find(c => c.id === id);
  const chap = (c, ch) => { const k = cat(c); return k && k.chapters.find(x => x.id === ch); };
  const topicsDone = (c, ch) => chap(c, ch).topics.filter(t => S.d.completedTopics.includes(`${c}/${ch}/${t.id}`)).length;
  const chapPct = (c, ch) => Math.round(topicsDone(c, ch) / chap(c, ch).topics.length * 100);
  const catPct = c => { const k = cat(c); let d = 0, t = 0; k.chapters.forEach(ch => { d += topicsDone(c, ch.id); t += ch.topics.length; }); return t ? Math.round(d / t * 100) : 0; };
  const bar = p => `<div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${p}"><i style="width:${p}%"></i></div>`;
  const back = (h, label) => `<button class="btn ghost sm backbtn" data-go="${h}">← ${esc(label || 'Back')}</button>`;
  const set = html => { view.innerHTML = `<div class="page">${html}</div>`; };
  const empty = (icon, title, msg, btn) => `<div class="empty"><div class="big">${icon}</div><h2>${esc(title)}</h2><p>${esc(msg)}</p>${btn || ''}</div>`;
  const countTopics = () => D.categories.reduce((n, c) => n + c.chapters.reduce((m, ch) => m + ch.topics.length, 0), 0);
  const countChapters = () => D.categories.reduce((n, c) => n + c.chapters.length, 0);
  const countQuestions = () => D.categories.reduce((n, c) => n + c.chapters.reduce((m, ch) => m + ch.practice.length, 0) + c.quizzes.reduce((m, q) => m + q.questions.length, 0), 0);

  function catCard(c) {
    const topics = c.chapters.reduce((n, ch) => n + ch.topics.length, 0);
    return `<article class="card cat"><div class="cicon">${c.icon}</div><h3>${esc(c.title)}</h3><p>${esc(c.description)}</p><small class="muted">${c.chapters.length} chapters · ${topics} topics · ${c.quizzes.length} quiz</small>${bar(catPct(c.id))}<button class="btn primary" data-go="category/${c.id}" aria-label="Open ${esc(c.title)}">Open</button></article>`;
  }
  function chCard(c, ch) {
    const k = cat(c), p = chapPct(c, ch.id), done = S.d.completedChapters.includes(`${c}/${ch.id}`);
    return `<article class="card chap"><small class="muted">${k.icon} ${esc(k.title)}</small><h3>${esc(ch.title)} ${done ? '<span class="tick" title="Completed">✓</span>' : ''}</h3><p>${esc(ch.description)}</p><small class="muted">${ch.topics.length} topics · ${ch.practice.length} practice questions</small>${bar(p)}<button class="btn" data-go="chapter/${c}/${ch.id}">Open chapter</button></article>`;
  }

  /* ---------- views ---------- */
  const views = {};
  views.home = () => {
    const last = labelFor(S.d.last), recent = S.d.recent.filter(k => { const [c, ch] = k.split('/'); return chap(c, ch); }).slice(0, 3);
    const totalCh = countChapters(), doneCh = S.d.completedChapters.length, doneTp = S.d.completedTopics.length;
    const scores = Object.values(S.d.quizScores), bestQ = scores.length ? Math.max(...scores.map(s => s.best)) : null;
    set(`
      <section class="hero"><div><h1>Learn. Practice. <span class="grad">Play.</span></h1><p>NEXORA turns short chapters, quizzes, tools and games into one app that works on your phone – even offline.</p>
      <button class="searchfield" data-act="search" aria-label="Open search">🔍 <span>Search topics, tools, games…</span></button>
      <div class="qa"><button class="btn primary" data-go="${last ? last.hash : 'categories'}">${last ? '▶ Continue' : '🚀 Start learning'}</button><button class="btn" data-go="explore">🧭 Explore</button><button class="btn" data-go="tools">🧰 Tools</button><button class="btn" data-go="games">🎮 Games</button><button class="btn" data-act="install">⬇ Install app</button></div></div></section>
      ${last ? `<section><h2>Continue learning</h2><article class="card row-card"><div><small class="muted">Last visited</small><h3>${esc(last.title)}</h3></div><button class="btn primary" data-go="${last.hash}">Resume</button></article></section>` : ''}
      <section><div class="sec-head"><h2>Your progress</h2><button class="btn ghost sm" data-go="progress">Details</button></div><div class="stats">
        <div class="card stat"><b>${doneCh}/${totalCh}</b><small>Chapters done</small></div><div class="card stat"><b>${doneTp}/${countTopics()}</b><small>Topics done</small></div>
        <div class="card stat"><b>${scores.length}/${D.categories.reduce((n, c) => n + c.quizzes.length, 0)}</b><small>Quizzes taken</small></div><div class="card stat"><b>${bestQ === null ? '—' : bestQ + '%'}</b><small>Best quiz score</small></div></div></section>
      <section><h2>Featured categories</h2><div class="grid">${D.categories.map(catCard).join('')}</div></section>
      <section><h2>Recent chapters</h2>${recent.length ? `<div class="grid">${recent.map(k => { const [c, ch] = k.split('/'); return chCard(c, chap(c, ch)); }).join('')}</div>` : empty('📖', 'No recent chapters yet', 'Open any chapter and it will show up here.', '<button class="btn primary" data-go="explore">Browse chapters</button>')}</section>
      <section><h2>Quick tools</h2><div class="grid mini">${D.tools.map(t => `<button class="card mini-card" data-go="tool/${t.id}"><span class="cicon">${t.icon}</span><b>${esc(t.title)}</b></button>`).join('')}</div></section>
      <section><h2>NEXORA in numbers</h2><div class="stats"><div class="card stat"><b>${D.categories.length}</b><small>Categories</small></div><div class="card stat"><b>${totalCh}</b><small>Chapters</small></div><div class="card stat"><b>${countTopics()}</b><small>Topics</small></div><div class="card stat"><b>${countQuestions()}</b><small>Questions</small></div></div></section>`);
  };
  views.categories = () => set(`<h1>Categories</h1><p class="muted">Pick a subject to see its chapters and quizzes.</p><div class="grid">${D.categories.map(catCard).join('')}</div>`);
  views.explore = () => {
    let f = 'all', q = '';
    set(`<h1>Explore</h1><p class="muted">Browse every chapter in NEXORA.</p><label class="lbl"><span class="sr">Filter chapters</span><input id="exq" type="search" placeholder="Filter chapters by name…"></label>
      <div class="chips" role="group" aria-label="Filter by category"><button class="chip on" data-c="all">All</button>${D.categories.map(c => `<button class="chip" data-c="${c.id}">${c.icon} ${esc(c.title)}</button>`).join('')}</div><div id="exlist" class="grid"></div>`);
    const draw = () => {
      const items = []; D.categories.forEach(c => { if (f === 'all' || f === c.id) c.chapters.forEach(ch => { if (!q || (ch.title + ' ' + ch.description).toLowerCase().includes(q)) items.push(chCard(c.id, ch)); }); });
      $('#exlist').innerHTML = items.length ? items.join('') : empty('🔎', 'No chapters found', 'Try a different word or choose “All”.');
    };
    $$('.chip').forEach(b => b.onclick = () => { f = b.dataset.c; $$('.chip').forEach(x => x.classList.toggle('on', x === b)); draw(); });
    $('#exq').oninput = e => { q = e.target.value.trim().toLowerCase(); draw(); };
    draw();
  };
  views.category = id => {
    const c = cat(id); if (!c) return notFound();
    set(`${back('categories', 'Categories')}<header class="ph"><div class="cicon lg">${c.icon}</div><div><h1>${esc(c.title)}</h1><p class="muted">${esc(c.description)}</p></div></header>${bar(catPct(id))}
      <section><h2>Chapters</h2><div class="grid">${c.chapters.map(ch => chCard(id, ch)).join('')}</div></section>
      <section><h2>Quizzes</h2><div class="grid">${c.quizzes.map(q => { const sc = S.d.quizScores[q.id]; return `<article class="card"><h3>📋 ${esc(q.title)}</h3><p>${esc(q.description)}</p><small class="muted">${q.questions.length} questions · ${Math.round(q.seconds / 60)} min timer option · Best: ${sc ? sc.best + '%' : '—'}</small><button class="btn primary" data-go="quiz/${id}/${q.id}">Open quiz</button></article>`; }).join('')}</div></section>`);
  };
  views.chapter = (cid, chid) => {
    const c = cat(cid), ch = chap(cid, chid); if (!ch) return notFound();
    const idx = c.chapters.indexOf(ch), prev = c.chapters[idx - 1], next = c.chapters[idx + 1], p = chapPct(cid, chid);
    set(`${back('category/' + cid, c.title)}<header class="ph"><div><h1>${esc(ch.title)}</h1><p class="muted">${esc(ch.description)}</p></div></header>
      <div class="card"><div class="sec-head"><b>Progress</b><span>${topicsDone(cid, chid)}/${ch.topics.length} topics · ${p}%</span></div>${bar(p)}</div>
      <section><h2>Learning objectives</h2><ul class="check">${ch.objectives.map(o => `<li>${esc(o)}</li>`).join('')}</ul></section>
      <section><h2>Topics</h2><div class="list">${ch.topics.map((t, i) => { const d = S.d.completedTopics.includes(`${cid}/${chid}/${t.id}`); return `<button class="card li" data-go="topic/${cid}/${chid}/${t.id}"><span class="num">${d ? '✓' : i + 1}</span><span><b>${esc(t.title)}</b><small class="muted">${d ? 'Completed' : 'Not completed'}</small></span></button>`; }).join('')}</div></section>
      <section><h2>Practice</h2><article class="card"><h3>✍️ Chapter practice</h3><p>${ch.practice.length} questions with instant feedback.${S.d.practiceBest[cid + '/' + chid] != null ? ' Best: ' + S.d.practiceBest[cid + '/' + chid] + '%.' : ''}</p><button class="btn primary" data-go="practice/${cid}/${chid}">Start practice</button></article></section>
      <section><h2>Quiz / test</h2><div class="grid">${c.quizzes.map(q => `<article class="card"><h3>📋 ${esc(q.title)}</h3><small class="muted">${q.questions.length} questions</small><button class="btn" data-go="quiz/${cid}/${q.id}">Open quiz</button></article>`).join('')}</div></section>
      <div class="pn">${prev ? `<button class="btn" data-go="chapter/${cid}/${prev.id}">← ${esc(prev.title)}</button>` : '<span></span>'}${next ? `<button class="btn" data-go="chapter/${cid}/${next.id}">${esc(next.title)} →</button>` : '<span></span>'}</div>`);
  };
  views.topic = (cid, chid, tid) => {
    const ch = chap(cid, chid), t = ch && ch.topics.find(x => x.id === tid); if (!t) return notFound();
    const i = ch.topics.indexOf(t), prev = ch.topics[i - 1], next = ch.topics[i + 1], key = `${cid}/${chid}/${tid}`;
    const draw = () => {
      const d = S.d.completedTopics.includes(key);
      set(`${back(`chapter/${cid}/${chid}`, ch.title)}<article class="card article"><small class="muted">Topic ${i + 1} of ${ch.topics.length}</small><h1>${esc(t.title)}</h1>${t.content}<h3>Example</h3><pre class="example">${t.example}</pre>
        <button class="btn ${d ? '' : 'primary'}" id="markdone" aria-pressed="${d}">${d ? '✓ Completed (tap to undo)' : 'Mark as complete'}</button></article>
        <div class="pn">${prev ? `<button class="btn" data-go="topic/${cid}/${chid}/${prev.id}">← ${esc(prev.title)}</button>` : '<span></span>'}${next ? `<button class="btn primary" data-go="topic/${cid}/${chid}/${next.id}">${esc(next.title)} →</button>` : `<button class="btn primary" data-go="practice/${cid}/${chid}">Practice →</button>`}</div>`);
      $('#markdone').onclick = () => {
        const a = S.d.completedTopics, ci = a.indexOf(key);
        if (ci >= 0) a.splice(ci, 1); else { a.push(key); toast('Topic completed ✓', 'ok'); }
        const ck = `${cid}/${chid}`, all = topicsDone(cid, chid) === ch.topics.length, cc = S.d.completedChapters, ix = cc.indexOf(ck);
        if (all && ix < 0) { cc.push(ck); toast('Chapter completed 🎉', 'ok'); NX.beep(880, 0.25); } else if (!all && ix >= 0) cc.splice(ix, 1);
        S.save(); if (!S.ok) toast('Progress cannot be saved on this browser.', 'err'); draw();
      };
    };
    draw();
  };
  views.practice = (cid, chid) => {
    const ch = chap(cid, chid); if (!ch) return notFound();
    NX.startQuiz({ mode: 'practice', title: ch.title + ' practice', qs: ch.practice, back: `chapter/${cid}/${chid}`, onFinish: (s, t, p) => { const k = cid + '/' + chid; if (S.d.practiceBest[k] == null || p > S.d.practiceBest[k]) S.d.practiceBest[k] = p; S.save(); } });
  };
  views.quiz = (cid, qid) => {
    const c = cat(cid), q = c && c.quizzes.find(x => x.id === qid); if (!q) return notFound();
    const sc = S.d.quizScores[qid];
    set(`${back('category/' + cid, c.title)}<article class="card center"><div class="big">📋</div><h1>${esc(q.title)}</h1><p>${esc(q.description)}</p><p class="muted">${q.questions.length} questions · Best score: <b>${sc ? sc.best + '%' : '—'}</b> · Attempts: ${sc ? sc.attempts : 0}</p>
      <label class="check-row"><input type="checkbox" id="qtimer"> Use timer (${Math.round(q.seconds / 60)} minutes)</label><button class="btn primary lg" id="qstart">▶ Start test</button></article>`);
    $('#qstart').onclick = () => NX.startQuiz({ mode: 'quiz', title: q.title, qs: q.questions, seconds: $('#qtimer').checked ? q.seconds : 0, back: `quiz/${cid}/${qid}`,
      onFinish: (s, t, p) => { const o = S.d.quizScores[qid] || { best: 0, last: 0, attempts: 0 }; o.best = Math.max(o.best, p); o.last = p; o.attempts++; S.d.quizScores[qid] = o; S.save(); } });
  };
  views.tools = () => set(`<h1>Tools</h1><p class="muted">Handy tools that work offline.</p><div class="grid">${D.tools.map(t => `<article class="card"><div class="cicon">${t.icon}</div><h3>${esc(t.title)}</h3><p>${esc(t.description)}</p><button class="btn primary" data-go="tool/${t.id}">Open</button></article>`).join('')}</div>`);
  views.tool = id => {
    const t = D.tools.find(x => x.id === id), fn = NX.tools[id]; if (!t || !fn) return notFound();
    set(`${back('tools', 'Tools')}<h1>${t.icon} ${esc(t.title)}</h1><div id="toolroot"></div>`);
    fn($('#toolroot'));
  };
  views.games = () => set(`<h1>Games</h1><p class="muted">Quick games to refresh your mind.</p><div class="grid">${D.games.map(g => { const b = S.d.games[g.id]; return `<article class="card"><div class="cicon">${g.icon}</div><h3>${esc(g.title)}</h3><p>${esc(g.description)}</p><small class="muted">Best: ${b ? b.best + ' ' + g.unit : '—'}</small><button class="btn primary" data-go="game/${g.id}">Play</button></article>`; }).join('')}</div>`);
  views.game = id => {
    const g = D.games.find(x => x.id === id); if (!g) return notFound();
    set(`${back('games', 'Games')}<div id="gameroot"></div>`); NX.mountGame(id, $('#gameroot'));
  };
  views.progress = () => {
    set(`${back('home', 'Home')}<h1>Your progress</h1>
      <section><h2>Chapters</h2><div class="list">${D.categories.map(c => c.chapters.map(ch => `<button class="card li" data-go="chapter/${c.id}/${ch.id}"><span class="num">${S.d.completedChapters.includes(c.id + '/' + ch.id) ? '✓' : '·'}</span><span><b>${esc(ch.title)}</b><small class="muted">${esc(c.title)} · ${topicsDone(c.id, ch.id)}/${ch.topics.length} topics · practice best ${S.d.practiceBest[c.id + '/' + ch.id] != null ? S.d.practiceBest[c.id + '/' + ch.id] + '%' : '—'}</small></span></button>`).join('')).join('')}</div></section>
      <section><h2>Quiz scores</h2><div class="list">${D.categories.map(c => c.quizzes.map(q => { const s = S.d.quizScores[q.id]; return `<div class="card li"><span class="num">📋</span><span><b>${esc(q.title)}</b><small class="muted">${s ? `Best ${s.best}% · Last ${s.last}% · ${s.attempts} attempt(s)` : 'Not attempted yet'}</small></span></div>`; }).join('')).join('')}</div></section>`);
  };
  views.settings = () => {
    const st = S.d.settings, dark = effTheme() === 'dark';
    set(`<h1>Settings</h1>
      <section class="card sets"><label class="row-set"><span><b>Dark mode</b><small class="muted">Easier on the eyes at night</small></span><input type="checkbox" role="switch" id="sTheme" ${dark ? 'checked' : ''}></label>
      <label class="row-set"><span><b>Animations</b><small class="muted">Turn off to reduce motion</small></span><input type="checkbox" role="switch" id="sAnim" ${st.anim ? 'checked' : ''}></label>
      <label class="row-set"><span><b>Sound</b><small class="muted">Beeps in quizzes, timer and games</small></span><input type="checkbox" role="switch" id="sSound" ${st.sound ? 'checked' : ''}></label></section>
      <section class="card sets"><h3>App</h3><p class="muted">Install NEXORA on your phone to open it like a normal app.</p><button class="btn primary" data-act="install">⬇ Install app</button></section>
      <section class="card sets"><h3>Data</h3><p class="muted">Storage status: <b>${S.ok ? 'available' : 'unavailable – progress will not persist'}</b></p><div class="row"><button class="btn" id="sReset">Reset progress</button><button class="btn danger" id="sClear">Clear all data</button></div></section>
      <section class="card sets"><h3>About NEXORA</h3><p>Version 1.0 · A static, offline-ready learning app built with HTML, CSS and JavaScript. Content: ${D.categories.length} categories, ${countChapters()} chapters, ${countTopics()} topics, ${countQuestions()} questions, ${D.tools.length} tools and ${D.games.length} games. All data stays on this device.</p></section>`);
    $('#sTheme').onchange = e => { st.theme = e.target.checked ? 'dark' : 'light'; S.save(); applySettings(); };
    $('#sAnim').onchange = e => { st.anim = e.target.checked; S.save(); applySettings(); };
    $('#sSound').onchange = e => { st.sound = e.target.checked; S.save(); if (st.sound) NX.beep(660); };
    $('#sReset').onclick = () => confirmBox('Reset progress?', 'Completed topics, chapters, quiz scores and game bests will be deleted. Notes and settings are kept.', 'Reset', () => { S.resetProgress(); toast('Progress reset', 'ok'); views.settings(); });
    $('#sClear').onclick = () => confirmBox('Clear all data?', 'This deletes progress, notes and settings from this device. It cannot be undone.', 'Clear everything', () => { S.clearAll(); applySettings(); toast('All data cleared', 'ok'); views.settings(); });
  };
  function notFound() { set(empty('🧭', 'Page not found', 'That page does not exist or has moved.', '<button class="btn primary" data-go="home">Go to Home</button>')); }
  function errorView(e) { set(empty('⚠️', 'Something went wrong', 'This page could not be shown. You can try again or go home.', '<div class="row"><button class="btn primary" data-act="reload">Try again</button><button class="btn" data-go="home">Home</button></div>')); }

  function labelFor(h) {
    if (!h) return null; const p = h.split('/');
    if (p[0] === 'chapter') { const ch = chap(p[1], p[2]); return ch ? { hash: h, title: ch.title } : null; }
    if (p[0] === 'topic') { const ch = chap(p[1], p[2]), t = ch && ch.topics.find(x => x.id === p[3]); return t ? { hash: h, title: ch.title + ' – ' + t.title } : null; }
    return null;
  }

  /* ---------- router ---------- */
  function route() {
    NX.cleanup(); closeModal();
    const parts = (location.hash.slice(1) || 'home').split('/').map(decodeURIComponent), name = parts[0];
    try {
      const fn = views[name];
      if (!fn) notFound(); else fn.apply(null, parts.slice(1));
      if (name === 'chapter' || name === 'topic') {
        S.d.last = parts.join('/'); const k = parts[1] + '/' + parts[2];
        S.d.recent = [k].concat(S.d.recent.filter(x => x !== k)).slice(0, 4); S.save();
      }
    } catch (e) { console.error(e); errorView(e); }
    const active = PARENT[name] || name;
    $$('[data-nav]').forEach(a => { const on = a.dataset.nav === active; a.classList.toggle('on', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
    window.scrollTo(0, 0);
  }

  /* ---------- search ---------- */
  function buildIndex() {
    const it = [];
    D.categories.forEach(c => {
      it.push({ t: 'Category', icon: c.icon, title: c.title, sub: c.description, go: 'category/' + c.id, k: c.title + ' ' + c.description });
      c.chapters.forEach(ch => {
        it.push({ t: 'Chapter', icon: '📖', title: ch.title, sub: c.title, go: `chapter/${c.id}/${ch.id}`, k: ch.title + ' ' + ch.description });
        ch.topics.forEach(tp => it.push({ t: 'Topic', icon: '📝', title: tp.title, sub: ch.title, go: `topic/${c.id}/${ch.id}/${tp.id}`, k: tp.title + ' ' + tp.content.replace(/<[^>]+>/g, ' ') }));
      });
    });
    D.tools.forEach(t => it.push({ t: 'Tool', icon: t.icon, title: t.title, sub: t.description, go: 'tool/' + t.id, k: t.title + ' ' + t.description }));
    D.games.forEach(g => it.push({ t: 'Game', icon: g.icon, title: g.title, sub: g.description, go: 'game/' + g.id, k: g.title + ' ' + g.description }));
    return it;
  }
  let index = null;
  function openSearch() {
    index = index || buildIndex();
    const d = modal({ title: 'Search', body: `<div class="sfield"><input id="sq" type="search" placeholder="Type to search…" aria-label="Search NEXORA" autocomplete="off"><button class="btn ghost sm" id="sclear" aria-label="Clear search" hidden>✕</button></div><div id="sres" class="sres" aria-live="polite"></div>` });
    const inp = $('#sq', d), res = $('#sres', d), clr = $('#sclear', d);
    const draw = () => {
      const q = inp.value.trim().toLowerCase(); clr.hidden = !q;
      if (!q) { res.innerHTML = '<p class="muted">Search categories, chapters, topics, tools and games.</p>'; return; }
      const words = q.split(/\s+/), hits = index.filter(x => { const s = (x.title + ' ' + x.k).toLowerCase(); return words.every(w => s.includes(w)); }).slice(0, 30);
      res.innerHTML = hits.length ? hits.map(h => `<button class="hit" data-go="${h.go}"><span>${h.icon}</span><span><b>${esc(h.title)}</b><small class="muted">${h.t} · ${esc(h.sub)}</small></span></button>`).join('') : empty('🔎', 'No results found', `Nothing matches “${q}”. Try another word.`);
    };
    inp.addEventListener('input', draw); clr.onclick = () => { inp.value = ''; draw(); inp.focus(); }; draw();
  }

  /* ---------- settings / theme ---------- */
  function effTheme() { return S.d.settings.theme || (matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark'); }
  function applySettings() {
    const th = effTheme(); document.documentElement.dataset.theme = th;
    document.documentElement.classList.toggle('no-anim', !S.d.settings.anim);
    const m = $('#themeColor'); if (m) m.content = th === 'dark' ? '#0b1020' : '#f4f6fb';
    const b = $('#btnTheme'); if (b) b.textContent = th === 'dark' ? '🌙' : '☀️';
  }

  /* ---------- PWA ---------- */
  let dip = null;
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); dip = e; });
  window.addEventListener('appinstalled', () => { dip = null; toast('NEXORA was installed on this device.', 'ok'); });
  async function install() {
    if (matchMedia('(display-mode: standalone)').matches || navigator.standalone) { toast('NEXORA is already running as an installed app.'); return; }
    if (dip) {
      const p = dip; dip = null;
      try { p.prompt(); const r = await p.userChoice; toast(r.outcome === 'accepted' ? 'Install accepted. Your browser is finishing the installation.' : 'Install was cancelled.'); } catch (e) { toast('The install prompt could not be shown.', 'err'); }
      return;
    }
    modal({ title: 'Install NEXORA', body: '<p>Your browser did not offer a one-tap install. You can install manually:</p><ul><li><b>Chrome (Android):</b> tap the ⋮ menu → <i>Install app</i> or <i>Add to Home screen</i>.</li><li><b>Edge:</b> tap ⋯ → <i>Add to phone</i> / <i>Install</i>.</li><li><b>Firefox (Android):</b> tap ⋮ → <i>Install</i>.</li><li><b>Desktop Chrome/Edge:</b> click the install icon in the address bar.</li></ul><p class="muted">The site must be opened over https (GitHub Pages is) and loaded at least once.</p>' });
  }
  function registerSW() {
    if (!('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;
    window.addEventListener('load', () => navigator.serviceWorker.register('service-worker.js').catch(err => console.warn('Service worker failed:', err)));
  }

  /* ---------- init ---------- */
  const actions = { search: openSearch, install, reload: route };
  document.addEventListener('click', e => {
    const g = e.target.closest('[data-go]');
    if (g) { e.preventDefault(); if ($('#modalRoot .overlay')) closeModal(); const h = g.dataset.go; if (location.hash === '#' + h) route(); else location.hash = h; return; }
    const a = e.target.closest('[data-act]'); if (a && actions[a.dataset.act]) actions[a.dataset.act]();
  });
  window.addEventListener('hashchange', route);
  window.addEventListener('error', () => toast('Something went wrong. Please try again.', 'err'));
  function init() {
    const nav = NAV.map(n => `<a href="#${n[0]}" data-nav="${n[0]}"><span aria-hidden="true">${n[2]}</span><span>${n[1]}</span></a>`).join('');
    $('#deskNav').innerHTML = nav; $('#bottomNav').innerHTML = nav;
    $('#btnTheme').onclick = () => { S.d.settings.theme = effTheme() === 'dark' ? 'light' : 'dark'; S.save(); applySettings(); const cb = $('#sTheme'); if (cb) cb.checked = effTheme() === 'dark'; };
    applySettings(); route(); registerSW();
    if (!S.ok) toast('Storage is unavailable – progress will not be saved.', 'err');
    setTimeout(() => { const s = $('#splash'); if (s) { s.classList.add('hide'); setTimeout(() => s.remove(), 400); } }, 350);
  }
  init();
})();
