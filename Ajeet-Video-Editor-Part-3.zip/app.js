const nameElement = document.getElementById("animatedName");
const words = ["I", "I am", "I am Ajeet", "I am Ajeet Vishwakarma"];
let wordIndex = 0;

function animateName() {
  nameElement.textContent = words[wordIndex];
  wordIndex++;

  if (wordIndex >= words.length) {
    setTimeout(() => {
      wordIndex = 0;
      animateName();
    }, 2200);
  } else {
    setTimeout(animateName, 800);
  }
}

animateName();

document.getElementById("startBtn").addEventListener("click", () => {
  alert("Video Editor module Part 2 will be added here.");
});

document.getElementById("projectsBtn").addEventListener("click", () => {
  alert("My Projects section will be added here.");
});

const modal = document.getElementById("settingsModal");

document.getElementById("settingsBtn").addEventListener("click", () => {
  modal.classList.remove("hidden");
});

document.getElementById("closeSettings").addEventListener("click", () => {
  modal.classList.add("hidden");
});

modal.addEventListener("click", (event) => {
  if (event.target === modal) {
    modal.classList.add("hidden");
  }
});

document.getElementById("darkMode").addEventListener("change", (event) => {
  if (!event.target.checked) {
    document.documentElement.style.setProperty("--bg", "#f4f4f7");
    document.documentElement.style.setProperty("--panel", "#ffffff");
    document.documentElement.style.setProperty("--panel2", "#eeeeF3");
    document.documentElement.style.setProperty("--text", "#15151b");
    document.documentElement.style.setProperty("--muted", "#555563");
  } else {
    document.documentElement.style.setProperty("--bg", "#08080d");
    document.documentElement.style.setProperty("--panel", "#111118");
    document.documentElement.style.setProperty("--panel2", "#171720");
    document.documentElement.style.setProperty("--text", "#f7f7fb");
    document.documentElement.style.setProperty("--muted", "#a6a6b4");
  }
});


/* Part 2 - Video Editor */
const videoInput = document.getElementById("videoInput");
const videoPreview = document.getElementById("videoPreview");
const emptyVideo = document.getElementById("emptyVideo");
const playBtn = document.getElementById("playBtn");
const timelineRange = document.getElementById("timelineRange");
const currentTimeEl = document.getElementById("currentTime");
const durationEl = document.getElementById("duration");
const editorSection = document.getElementById("editorSection");
const removeVideo = document.getElementById("removeVideo");
const startBtn = document.getElementById("startBtn");
const backHomeBtn = document.getElementById("backHomeBtn");
const back10 = document.getElementById("back10");
const forward10 = document.getElementById("forward10");

let videoURL = null;

function formatTime(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return "00:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return String(mins).padStart(2, "0") + ":" + String(secs).padStart(2, "0");
}

function openEditor() {
  editorSection.scrollIntoView({ behavior: "smooth", block: "start" });
}

startBtn.addEventListener("click", openEditor);

backHomeBtn.addEventListener("click", () => {
  window.scrollTo({ top: 0, behavior: "smooth" });
});

videoInput.addEventListener("change", () => {
  const file = videoInput.files && videoInput.files[0];
  if (!file) return;

  if (videoURL) URL.revokeObjectURL(videoURL);
  videoURL = URL.createObjectURL(file);

  videoPreview.src = videoURL;
  videoPreview.style.display = "block";
  emptyVideo.style.display = "none";
  timelineRange.disabled = false;
  videoPreview.load();
});

videoPreview.addEventListener("loadedmetadata", () => {
  timelineRange.max = videoPreview.duration || 0;
  timelineRange.value = 0;
  durationEl.textContent = formatTime(videoPreview.duration);
  currentTimeEl.textContent = "00:00";
});

videoPreview.addEventListener("timeupdate", () => {
  timelineRange.value = videoPreview.currentTime;
  currentTimeEl.textContent = formatTime(videoPreview.currentTime);
});

videoPreview.addEventListener("play", () => {
  playBtn.textContent = "❚❚";
});

videoPreview.addEventListener("pause", () => {
  playBtn.textContent = "▶";
});

playBtn.addEventListener("click", () => {
  if (!videoPreview.src) return;
  if (videoPreview.paused) {
    videoPreview.play();
  } else {
    videoPreview.pause();
  }
});

timelineRange.addEventListener("input", () => {
  if (!videoPreview.duration) return;
  videoPreview.currentTime = Number(timelineRange.value);
});

back10.addEventListener("click", () => {
  if (!videoPreview.src) return;
  videoPreview.currentTime = Math.max(0, videoPreview.currentTime - 10);
});

forward10.addEventListener("click", () => {
  if (!videoPreview.src) return;
  videoPreview.currentTime = Math.min(
    videoPreview.duration || 0,
    videoPreview.currentTime + 10
  );
});

removeVideo.addEventListener("click", () => {
  videoPreview.pause();
  videoPreview.removeAttribute("src");
  videoPreview.load();

  if (videoURL) {
    URL.revokeObjectURL(videoURL);
    videoURL = null;
  }

  videoInput.value = "";
  videoPreview.style.display = "none";
  emptyVideo.style.display = "grid";
  timelineRange.disabled = true;
  timelineRange.value = 0;
  currentTimeEl.textContent = "00:00";
  durationEl.textContent = "00:00";
  playBtn.textContent = "▶";
});


/* Part 3 - Trim, Speed and Transform */
const trimStart = document.getElementById("trimStart");
const trimEnd = document.getElementById("trimEnd");
const trimStartValue = document.getElementById("trimStartValue");
const trimEndValue = document.getElementById("trimEndValue");
const applyTrim = document.getElementById("applyTrim");
const zoomRange = document.getElementById("zoomRange");
const zoomValue = document.getElementById("zoomValue");
const rotateLeft = document.getElementById("rotateLeft");
const resetTransform = document.getElementById("resetTransform");

let trimIn = 0;
let trimOut = 0;
let rotation = 0;
let zoom = 1;

function updateTrimUI() {
  trimStartValue.textContent = formatTime(trimIn);
  trimEndValue.textContent = formatTime(trimOut || videoPreview.duration || 0);
}

videoPreview.addEventListener("loadedmetadata", () => {
  const d = Number(videoPreview.duration) || 0;
  trimStart.max = d;
  trimEnd.max = d;
  trimStart.value = 0;
  trimEnd.value = d;
  trimStart.disabled = false;
  trimEnd.disabled = false;
  trimIn = 0;
  trimOut = d;
  updateTrimUI();
  zoomRange.disabled = false;
});

trimStart.addEventListener("input", () => {
  const d = Number(videoPreview.duration) || 0;
  trimIn = Math.min(Number(trimStart.value), Math.max(0, trimOut - 0.05));
  trimStart.value = trimIn;
  updateTrimUI();
  if (videoPreview.src) videoPreview.currentTime = trimIn;
});

trimEnd.addEventListener("input", () => {
  const d = Number(videoPreview.duration) || 0;
  trimOut = Math.max(Number(trimEnd.value), Math.min(d, trimIn + 0.05));
  trimEnd.value = trimOut;
  updateTrimUI();
  if (videoPreview.src) videoPreview.currentTime = trimOut;
});

videoPreview.addEventListener("timeupdate", () => {
  if (trimOut > trimIn && videoPreview.currentTime >= trimOut) {
    videoPreview.pause();
    videoPreview.currentTime = trimIn;
  }
});

applyTrim.addEventListener("click", () => {
  if (!videoPreview.src || !videoPreview.duration) return;
  if (trimOut <= trimIn) return;
  videoPreview.currentTime = trimIn;
  currentTimeEl.textContent = formatTime(trimIn);
  alert("Trim range applied to the preview. Final rendered export will be added in the Export module.");
});

document.querySelectorAll(".speed-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    if (!videoPreview.src) return;
    const speed = Number(btn.dataset.speed);
    videoPreview.playbackRate = speed;
    document.querySelectorAll(".speed-btn").forEach(b => b.classList.remove("selected"));
    btn.classList.add("selected");
  });
});

zoomRange.addEventListener("input", () => {
  zoom = Number(zoomRange.value);
  zoomValue.textContent = zoom.toFixed(1) + "×";
  videoPreview.style.transform = `rotate(${rotation}deg) scale(${zoom})`;
});

rotateLeft.addEventListener("click", () => {
  if (!videoPreview.src) return;
  rotation = (rotation - 90) % 360;
  videoPreview.style.transform = `rotate(${rotation}deg) scale(${zoom})`;
});

resetTransform.addEventListener("click", () => {
  rotation = 0;
  zoom = 1;
  zoomRange.value = 1;
  zoomValue.textContent = "1.0×";
  videoPreview.style.transform = "rotate(0deg) scale(1)";
});

const originalRemoveHandler = removeVideo.onclick;
removeVideo.addEventListener("click", () => {
  trimStart.disabled = true;
  trimEnd.disabled = true;
  zoomRange.disabled = true;
  trimStart.value = 0;
  trimEnd.value = 0;
  trimIn = 0;
  trimOut = 0;
  rotation = 0;
  zoom = 1;
  zoomRange.value = 1;
  zoomValue.textContent = "1.0×";
  videoPreview.style.transform = "none";
  document.querySelectorAll(".speed-btn").forEach(b => b.classList.remove("selected"));
});
