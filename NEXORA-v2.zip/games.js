/* NEXORA games: 25 playable games built from a few engines. Add a game = add data in data.js + an entry here. */
(function () {
  'use strict';
  const { $, $$, esc, shuffle, onCleanup, Store, beep } = NX, D = NEXORA_DATA, B = D.banks;
  const R = (a, b) => a + Math.floor(Math.random() * (b - a + 1)), pick = a => a[R(0, a.length - 1)];
  const deck = arr => { let q = []; return () => { if (!q.length) q = shuffle(arr); return q.pop(); }; };
  const hud = (l, r) => `<div class="g-hud"><span class="pill">${l}</span><span class="pill" id="gtime">${r || ''}</span></div>`;
  const impl = {};

  /* ---- Engine 1: multiple-choice rounds ---- */
  function rounds(cfg) {
    return (area, finish) => {
      let score = 0, asked = 0, left = cfg.seconds || 0, lock = false, cur = null, to = null, iv = null, over = false;
      area.innerHTML = hud('Score: <b id="gscore">0</b>') + '<div id="rq"></div>';
      const upd = () => { $('#gtime', area).textContent = cfg.seconds ? '⏱ ' + left + 's' : 'Q ' + Math.min(asked + 1, cfg.total) + '/' + cfg.total; };
      const end = () => { if (over) return; over = true; clearInterval(iv); clearTimeout(to); finish(score, 'You scored ' + score + '.'); };
      function next() {
        if (over) return; if (cfg.total && asked >= cfg.total) return end();
        lock = false; cur = cfg.gen(); const q = $('#rq', area);
        q.innerHTML = `<div class="gq">${cur.html || esc(cur.q)}</div><div class="opts">${cur.options.map((o, i) => `<button class="opt" data-i="${i}"><b>${'ABCD'[i]}</b><span>${esc(o)}</span></button>`).join('')}</div><div class="feedback" id="rfb" hidden></div>`;
        upd();
        $$('.opt', q).forEach(b => b.onclick = () => {
          if (lock || over) return; lock = true; asked++;
          const ok = +b.dataset.i === cur.answer;
          if (ok) { score += 1; b.classList.add('correct'); beep(760, 0.06); }
          else { b.classList.add('wrong'); $$('.opt', q)[cur.answer].classList.add('correct'); beep(200, 0.15); if (cfg.penalty) score = Math.max(0, score - 1); }
          if (cur.info) { const f = $('#rfb', area); f.hidden = false; f.textContent = cur.info; }
          $('#gscore', area).textContent = score; to = setTimeout(next, ok ? 350 : 950);
        });
      }
      if (cfg.seconds) iv = setInterval(() => { left--; upd(); if (left <= 0) end(); }, 1000);
      onCleanup(() => { over = true; clearInterval(iv); clearTimeout(to); }); next();
    };
  }
  const numOpts = ans => { const s = new Set([ans]); while (s.size < 4) { const v = ans + R(1, 10) * (Math.random() < 0.5 ? -1 : 1); if (v >= 0) s.add(v); } const o = shuffle([...s]); return { options: o.map(String), answer: o.indexOf(ans) }; };
  const math = op => () => {
    const o = op === 'mix' ? pick(['+', '−', '×', '÷']) : op; let a, b, ans;
    if (o === '+') { a = R(5, 60); b = R(5, 60); ans = a + b; } else if (o === '−') { a = R(20, 90); b = R(5, a); ans = a - b; }
    else if (o === '×') { a = R(2, 12); b = R(2, 12); ans = a * b; } else { b = R(2, 12); ans = R(2, 12); a = b * ans; }
    return Object.assign({ q: a + ' ' + o + ' ' + b + ' = ?' }, numOpts(ans));
  };
  const scramble = list => { const d = deck(list); return () => { const w = d(); let s = w; for (let i = 0; i < 20 && s === w; i++) s = shuffle(w.split('')).join(''); const others = shuffle(list.filter(x => x !== w)).slice(0, 3), o = shuffle([w, ...others]); return { q: 'Unscramble: ' + s.toUpperCase(), options: o, answer: o.indexOf(w) }; }; };
  const tf = list => { const d = deck(list); return () => { const x = d(); return { q: x[0], options: ['True', 'False'], answer: x[1] ? 0 : 1 }; }; };
  const capitals = (() => { const d = deck(B.capitals); return () => { const x = d(), o = shuffle([x[1], ...shuffle(B.capitals.filter(c => c[1] !== x[1])).slice(0, 3).map(c => c[1])]); return { q: 'What is the capital of ' + x[0] + '?', options: o, answer: o.indexOf(x[1]) }; }; })();
  const sequence = () => {
    const t = R(0, 2); let terms, ans;
    if (t === 0) { const s = R(1, 20), d = R(2, 9); terms = [0, 1, 2, 3].map(i => s + i * d); ans = s + 4 * d; }
    else if (t === 1) { const s = R(1, 4), r = R(2, 3); terms = [0, 1, 2, 3].map(i => s * Math.pow(r, i)); ans = s * Math.pow(r, 4); }
    else { const n = R(1, 6); terms = [0, 1, 2, 3].map(i => (n + i) * (n + i)); ans = (n + 4) * (n + 4); }
    return Object.assign({ q: terms.join(', ') + ', ?' }, numOpts(ans));
  };
  const oddone = (() => { const d = deck(B.odd); return () => { const x = d(), o = shuffle([...x[0], x[1]]); return { q: 'Which one does not belong?', options: o, answer: o.indexOf(x[1]) }; }; })();
  const COL = [['Red', '#ef4444'], ['Blue', '#3b82f6'], ['Green', '#22c55e'], ['Yellow', '#eab308'], ['Purple', '#a855f7']];
  const stroop = () => { const w = pick(COL), ink = pick(COL.filter(c => c !== w)), o = shuffle([ink, ...shuffle(COL.filter(c => c !== ink)).slice(0, 3)]); return { html: `<span style="color:${ink[1]};font-size:2.6rem;font-weight:800">${w[0]}</span><small>Pick the colour of the ink</small>`, options: o.map(c => c[0]), answer: o.indexOf(ink) }; };
  const hilo = () => { const a = R(1, 99); let b = R(1, 99); while (b === a) b = R(1, 99); return { q: 'Current number: ' + a + '. Will the next number be higher or lower?', options: ['Higher', 'Lower'], answer: b > a ? 0 : 1, info: 'The next number was ' + b + '.' }; };
  const RG = {
    add: { seconds: 45, gen: math('+') }, sub: { seconds: 45, gen: math('−') }, mult: { seconds: 45, gen: math('×') }, div: { seconds: 45, gen: math('÷') }, mixmath: { seconds: 60, gen: math('mix'), penalty: 1 },
    'scramble-sci': { seconds: 60, gen: scramble(B.sciWords) }, 'scramble-tech': { seconds: 60, gen: scramble(B.techWords) },
    'tf-sci': { total: 10, gen: tf(B.tfSci) }, 'tf-tech': { total: 10, gen: tf(B.tfTech) }, capitals: { total: 10, gen: capitals },
    sequence: { seconds: 60, gen: sequence }, oddone: { total: 8, gen: oddone }, stroop: { seconds: 30, gen: stroop }, hilo: { seconds: 40, gen: hilo }
  };
  Object.keys(RG).forEach(k => impl[k] = rounds(RG[k]));

  /* ---- Engine 2: memory pairs ---- */
  function memory(pairs) {
    return (area, finish) => {
      const cards = shuffle(pairs.flatMap((p, i) => [{ id: i, t: p[0] }, { id: i, t: p[1] }]));
      let first = null, lock = false, moves = 0, matched = 0, secs = 0, to = null;
      area.innerHTML = hud('Moves: <b id="gscore">0</b>', '⏱ 0s') + `<div class="mem-grid">${cards.map((c, i) => `<button class="mcard" data-id="${c.id}" aria-label="Card ${i + 1}, hidden"><span class="face ${c.t.length > 2 ? 'txt' : ''}">${esc(c.t)}</span></button>`).join('')}</div>`;
      const iv = setInterval(() => { secs++; $('#gtime', area).textContent = '⏱ ' + secs + 's'; }, 1000);
      onCleanup(() => { clearInterval(iv); clearTimeout(to); });
      $$('.mcard', area).forEach(c => c.addEventListener('click', () => {
        if (lock || c.classList.contains('flip') || c.classList.contains('done')) return;
        c.classList.add('flip'); beep(500, 0.05);
        if (!first) { first = c; return; }
        moves++; $('#gscore', area).textContent = moves;
        if (first.dataset.id === c.dataset.id) {
          first.classList.add('done'); c.classList.add('done'); first = null; matched++; beep(800, 0.1);
          if (matched === pairs.length) { clearInterval(iv); to = setTimeout(() => finish(moves, 'Solved in ' + moves + ' moves and ' + secs + ' seconds.'), 500); }
        } else { lock = true; const a = first; first = null; to = setTimeout(() => { a.classList.remove('flip'); c.classList.remove('flip'); lock = false; }, 800); }
      }));
    };
  }
  impl.memory = memory(['🚀', '🌍', '🧠', '⚡', '🎯', '🔬'].map(e => [e, e]));
  impl.elements = memory(B.elements);

  /* ---- Reflex and single games ---- */
  impl.quicktap = (area, finish) => {
    let score = 0, left = 30, mv = null;
    area.innerHTML = hud('Score: <b id="gscore">0</b>', '⏱ 30s') + '<div class="arena" id="arena"><button class="target" id="target" aria-label="Tap target">🎯</button></div>';
    const arena = $('#arena', area), tg = $('#target', area);
    const move = () => { tg.style.left = Math.random() * Math.max(0, arena.clientWidth - 64) + 'px'; tg.style.top = Math.random() * Math.max(0, arena.clientHeight - 64) + 'px'; };
    const loop = () => { clearInterval(mv); mv = setInterval(move, 1100); };
    move(); loop();
    const iv = setInterval(() => { left--; $('#gtime', area).textContent = '⏱ ' + left + 's'; if (left <= 0) { clearInterval(iv); clearInterval(mv); finish(score, 'You hit ' + score + ' targets in 30 seconds.'); } }, 1000);
    onCleanup(() => { clearInterval(iv); clearInterval(mv); });
    tg.addEventListener('click', () => { score++; $('#gscore', area).textContent = score; beep(700, 0.05); move(); loop(); });
  };
  impl.reaction = (area, finish) => {
    let round = 0, times = [], t0 = 0, to = null, state = 'idle';
    area.innerHTML = hud('Average of 3 rounds', 'Round 1/3') + '<button class="react" id="rbox">Tap to begin</button>';
    const box = $('#rbox', area);
    function arm() { state = 'wait'; box.className = 'react wait'; box.textContent = 'Wait for green…'; to = setTimeout(() => { state = 'go'; t0 = performance.now(); box.className = 'react go'; box.textContent = 'TAP NOW!'; }, R(1500, 4000)); }
    box.onclick = () => {
      if (state === 'idle') arm();
      else if (state === 'wait') { clearTimeout(to); state = 'idle'; box.className = 'react early'; box.textContent = 'Too early! Tap to try again'; }
      else if (state === 'go') {
        const ms = Math.round(performance.now() - t0); times.push(ms); round++; state = 'idle';
        if (round >= 3) { finish(Math.round(times.reduce((a, b) => a + b, 0) / 3), 'Your times: ' + times.join(' ms, ') + ' ms.'); return; }
        box.className = 'react'; box.textContent = ms + ' ms – tap for the next round'; $('#gtime', area).textContent = 'Round ' + (round + 1) + '/3';
      }
    };
    onCleanup(() => clearTimeout(to));
  };
  impl.simon = (area, finish) => {
    const seq = [], cols = ['#ef4444', '#22c55e', '#3b82f6', '#eab308']; let pos = 0, busy = true, tos = [];
    area.innerHTML = hud('Level: <b id="gscore">0</b>', 'Watch…') + `<div class="simon">${cols.map((c, i) => `<button class="pad" style="--c:${c}" aria-label="Pad ${i + 1}"></button>`).join('')}</div>`;
    const pads = $$('.pad', area), st = t => { $('#gtime', area).textContent = t; };
    const flash = i => { pads[i].classList.add('lit'); beep(300 + i * 120, 0.2); tos.push(setTimeout(() => pads[i].classList.remove('lit'), 350)); };
    function round() { busy = true; pos = 0; seq.push(R(0, 3)); st('Watch…'); seq.forEach((s, k) => tos.push(setTimeout(() => flash(s), 700 + k * 600))); tos.push(setTimeout(() => { busy = false; st('Your turn'); }, 700 + seq.length * 600)); }
    pads.forEach((p, i) => p.onclick = () => {
      if (busy) return; flash(i);
      if (i !== seq[pos]) { busy = true; tos.push(setTimeout(() => finish(seq.length - 1, 'You reached level ' + (seq.length - 1) + '.'), 500)); return; }
      pos++; if (pos === seq.length) { $('#gscore', area).textContent = seq.length; busy = true; tos.push(setTimeout(round, 800)); }
    });
    onCleanup(() => tos.forEach(clearTimeout)); round();
  };
  impl.whack = (area, finish) => {
    let score = 0, left = 30, cur = -1, mt = null;
    area.innerHTML = hud('Score: <b id="gscore">0</b>', '⏱ 30s') + `<div class="holes">${Array.from({ length: 9 }, (_, i) => `<button class="hole" aria-label="Hole ${i + 1}"></button>`).join('')}</div>`;
    const hs = $$('.hole', area);
    const show = () => { hs.forEach(h => h.textContent = ''); cur = R(0, 8); hs[cur].textContent = '🐹'; mt = setTimeout(show, R(550, 900)); };
    hs.forEach((h, i) => h.onclick = () => { if (i === cur) { score++; $('#gscore', area).textContent = score; h.textContent = '💥'; cur = -1; beep(700, 0.05); } });
    const iv = setInterval(() => { left--; $('#gtime', area).textContent = '⏱ ' + left + 's'; if (left <= 0) { clearInterval(iv); clearTimeout(mt); finish(score, 'You whacked ' + score + ' moles.'); } }, 1000);
    onCleanup(() => { clearInterval(iv); clearTimeout(mt); }); show();
  };
  impl.tictactoe = (area, finish) => {
    const b = Array(9).fill(''), L = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]]; let over = false, to = null;
    const win = p => L.some(l => l.every(i => b[i] === p)), full = () => b.every(Boolean);
    area.innerHTML = hud('You ❌ vs Computer ⭕', 'Your move') + `<div class="ttt">${b.map((_, i) => `<button class="cell" aria-label="Cell ${i + 1}"></button>`).join('')}</div>`;
    const cells = $$('.cell', area), draw = () => cells.forEach((c, i) => { c.textContent = b[i] === 'X' ? '❌' : b[i] === 'O' ? '⭕' : ''; c.disabled = !!b[i] || over; });
    const end = (pts, msg) => { over = true; draw(); to = setTimeout(() => finish(pts, msg), 800); };
    const tryWin = p => { const free = b.map((v, i) => v ? null : i).filter(v => v !== null); return free.find(i => { b[i] = p; const w = win(p); b[i] = ''; return w; }); };
    cells.forEach((c, i) => c.onclick = () => {
      if (over || b[i]) return; b[i] = 'X'; beep(600, 0.05);
      if (win('X')) return end(3, 'You win!'); if (full()) return end(1, 'It is a draw.');
      let m = tryWin('O'); if (m == null) m = tryWin('X'); if (m == null) m = pick(b.map((v, k) => v ? null : k).filter(v => v !== null));
      b[m] = 'O'; if (win('O')) return end(0, 'The computer wins.'); if (full()) return end(1, 'It is a draw.'); draw();
    });
    onCleanup(() => clearTimeout(to)); draw();
  };
  impl.guess = (area, finish) => {
    const secret = R(1, 100); let tries = 7;
    area.innerHTML = hud('Tries left: <b id="gscore">7</b>', '1 to 100') + '<label class="lbl">Your guess<input id="gin" type="number" inputmode="numeric" min="1" max="100"></label><button class="btn primary" id="gbtn">Guess</button><div class="feedback" id="gfb" role="status">Type a number and tap Guess.</div>';
    const go = () => {
      const v = parseInt($('#gin', area).value, 10), fb = $('#gfb', area);
      if (!(v >= 1 && v <= 100)) { fb.textContent = 'Enter a whole number from 1 to 100.'; return; }
      tries--; $('#gscore', area).textContent = tries;
      if (v === secret) return finish((tries + 1) * 10, 'Correct! The number was ' + secret + '.');
      if (tries === 0) return finish(0, 'Out of tries. The number was ' + secret + '.');
      fb.textContent = v < secret ? '⬆ Higher than ' + v : '⬇ Lower than ' + v; $('#gin', area).value = ''; $('#gin', area).focus();
    };
    $('#gbtn', area).onclick = go; $('#gin', area).addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  };
  impl.hangman = (area, finish) => {
    const word = pick(B.sciWords.concat(B.techWords)).toUpperCase(), got = new Set(); let lives = 6;
    area.innerHTML = hud('Lives: <b id="gscore">6</b>', 'Guess the word') + '<div class="hword" id="hw" aria-live="polite"></div><div class="keys">' + 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(k => `<button class="key" data-k="${k}">${k}</button>`).join('') + '</div>';
    const show = () => { $('#hw', area).textContent = word.split('').map(c => got.has(c) ? c : '_').join(' '); };
    $$('.key', area).forEach(b => b.onclick = () => {
      const k = b.dataset.k; b.disabled = true; got.add(k);
      if (word.includes(k)) { b.classList.add('hit'); beep(700, 0.05); } else { lives--; b.classList.add('miss'); beep(200, 0.1); $('#gscore', area).textContent = lives; }
      show();
      if (word.split('').every(c => got.has(c))) finish(10 + lives * 5, 'You found ' + word + '!');
      else if (lives <= 0) finish(0, 'The word was ' + word + '.');
    });
    show();
  };
  impl.slide = (area, finish) => {
    let t = [1, 2, 3, 4, 5, 6, 7, 8, 0], moves = 0, e = 8;
    const adj = i => [[1, 3], [0, 2, 4], [1, 5], [0, 4, 6], [1, 3, 5, 7], [2, 4, 8], [3, 7], [4, 6, 8], [5, 7]][i];
    for (let k = 0; k < 80; k++) { const n = pick(adj(e)); t[e] = t[n]; t[n] = 0; e = n; }
    if (t.every((v, i) => v === (i + 1) % 9)) { t = [1, 2, 3, 4, 5, 6, 0, 7, 8]; e = 6; }
    area.innerHTML = hud('Moves: <b id="gscore">0</b>', 'Order 1 to 8') + '<div class="slide" id="sb"></div>';
    const draw = () => { $('#sb', area).innerHTML = t.map((v, i) => `<button class="tile ${v ? '' : 'blank'}" data-i="${i}" ${v ? '' : 'disabled'} aria-label="${v ? 'Tile ' + v : 'Empty'}">${v || ''}</button>`).join(''); $$('.tile', area).forEach(b => b.onclick = () => click(+b.dataset.i)); };
    function click(i) {
      if (!adj(e).includes(i)) return; t[e] = t[i]; t[i] = 0; e = i; moves++; $('#gscore', area).textContent = moves; beep(450, 0.04); draw();
      if (t.every((v, k) => v === (k + 1) % 9)) setTimeout(() => finish(moves, 'Solved in ' + moves + ' moves.'), 400);
    }
    draw();
  };
  impl.typing = (area, finish) => {
    const s = pick(B.sentences); let t0 = 0;
    area.innerHTML = hud('Type the sentence', '0 WPM') + '<p class="tsent" id="ts" aria-label="Sentence to type"></p><label class="lbl">Your typing<textarea id="tin" rows="3" autocomplete="off" autocapitalize="off" spellcheck="false"></textarea></label>';
    const ts = $('#ts', area), inp = $('#tin', area);
    const paint = v => { ts.innerHTML = s.split('').map((c, i) => `<span class="${i < v.length ? (v[i] === c ? 'ok' : 'bad') : ''}">${esc(c)}</span>`).join(''); };
    paint(''); inp.focus();
    inp.addEventListener('input', () => {
      const v = inp.value; if (!t0 && v) t0 = performance.now(); paint(v);
      const mins = Math.max((performance.now() - t0) / 60000, 0.0005), good = v.split('').filter((c, i) => c === s[i]).length;
      $('#gtime', area).textContent = Math.round(good / 5 / mins) + ' WPM';
      if (v === s) finish(Math.round(s.length / 5 / mins), 'You typed it in ' + ((performance.now() - t0) / 1000).toFixed(1) + ' seconds.');
    });
  };

  /* ---- Game shell: intro -> play -> result ---- */
  NX.mountGame = function (id, root) {
    const g = D.games.find(x => x.id === id), run = impl[id];
    if (!g || !run) { root.innerHTML = '<div class="empty"><div class="big">🎮</div><h3>Game not found</h3><button class="btn primary" data-go="games">All games</button></div>'; return; }
    const best = () => (Store.d.games[id] || {}).best;
    function intro() {
      root.innerHTML = `<div class="card tool center"><div class="big">${g.icon}</div><h2>${esc(g.title)}</h2><p>${esc(g.instructions)}</p><p class="muted">Best: <b>${best() == null ? '—' : best() + ' ' + g.unit}</b></p><button class="btn primary lg" id="gstart">▶ Start game</button></div>`;
      $('#gstart', root).onclick = play;
    }
    function play() {
      NX.cleanup(); root.innerHTML = '<div class="card tool" id="garea"></div>';
      run($('#garea', root), (score, text) => {
        NX.cleanup(); const b = best(), isNew = b == null || (g.bestMode === 'low' ? score < b : score > b);
        if (isNew) { Store.d.games[id] = { best: score }; Store.save(); }
        NX.award('g:' + id, 10); beep(isNew ? 900 : 500, 0.3);
        root.innerHTML = `<div class="card tool center"><div class="big">${isNew ? '🏆' : '🏁'}</div><h2>Game over</h2><p>${esc(text)}</p><p><b>Score: ${score} ${esc(g.unit)}</b>${isNew ? '<br><span class="okc">New best!</span>' : ''}</p><div class="row"><button class="btn primary" id="gagain">↻ Play again</button><button class="btn" data-go="games">All games</button></div></div>`;
        $('#gagain', root).onclick = play;
      });
    }
    intro();
  };
})();
