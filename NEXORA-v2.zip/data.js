/* NEXORA content. To add content, just add objects to these arrays – no app code changes needed. */
const NEXORA_DATA = {
  categories: [
    {
      id: 'web', title: 'Web Development', icon: '💻',
      description: 'Build web pages with HTML and CSS, step by step.',
      chapters: [
        {
          id: 'html-basics', title: 'HTML Basics',
          description: 'Learn how web pages are structured using tags and attributes.',
          objectives: ['Explain what HTML is', 'Write headings, paragraphs and lists', 'Add links and images correctly'],
          topics: [
            { id: 'what-is-html', title: 'What is HTML?',
              content: '<p>HTML (HyperText Markup Language) describes the structure of a web page. Browsers read HTML and turn it into headings, text, images and buttons.</p><p>Every page has a <code>&lt;head&gt;</code> for settings and a <code>&lt;body&gt;</code> for visible content.</p>',
              example: '&lt;h1&gt;Hello NEXORA&lt;/h1&gt;\n&lt;p&gt;My first page.&lt;/p&gt;' },
            { id: 'tags-attributes', title: 'Tags and Attributes',
              content: '<p>Most elements have an opening tag and a closing tag, like <code>&lt;p&gt;…&lt;/p&gt;</code>. Attributes add extra information inside the opening tag, such as <code>class</code> or <code>id</code>.</p><ul><li><code>&lt;h1&gt;</code> to <code>&lt;h6&gt;</code>: headings (h1 is the largest)</li><li><code>&lt;p&gt;</code>: paragraph</li><li><code>&lt;ul&gt;</code> and <code>&lt;li&gt;</code>: bullet list</li></ul>',
              example: '&lt;p class="intro"&gt;Welcome!&lt;/p&gt;' },
            { id: 'links-images', title: 'Links and Images',
              content: '<p>Use <code>&lt;a href="…"&gt;</code> to link to another page. Use <code>&lt;img src="…" alt="…"&gt;</code> to show a picture. The <code>alt</code> text describes the image for screen readers and shows if the image fails to load.</p>',
              example: '&lt;a href="about.html"&gt;About us&lt;/a&gt;\n&lt;img src="logo.png" alt="NEXORA logo"&gt;' }
          ],
          practice: [
            { q: 'Which tag creates the largest heading?', options: ['<h6>', '<h1>', '<head>', '<title>'], answer: 1, explain: '<h1> is the top-level and largest heading.' },
            { q: 'Which attribute gives a link its destination?', options: ['src', 'href', 'alt', 'link'], answer: 1, explain: 'href holds the URL a link points to.' },
            { q: 'What does the alt attribute on an image provide?', options: ['Image size', 'Alternative text', 'Border style', 'Link target'], answer: 1, explain: 'alt is text shown or read aloud when the image cannot be seen.' }
          ]
        },
        {
          id: 'css-basics', title: 'CSS Basics',
          description: 'Style your pages with selectors, spacing and flexible layouts.',
          objectives: ['Select elements with CSS selectors', 'Understand the box model', 'Build a simple layout with Flexbox'],
          topics: [
            { id: 'selectors', title: 'Selectors',
              content: '<p>A selector chooses which elements a rule applies to. An element selector uses the tag name (<code>p</code>), a class selector starts with a dot (<code>.card</code>) and an id selector starts with a hash (<code>#menu</code>).</p>',
              example: '.card { color: teal; }\np { line-height: 1.6; }' },
            { id: 'box-model', title: 'The Box Model',
              content: '<p>Every element is a box made of four layers, from inside to outside: <b>content</b>, <b>padding</b>, <b>border</b> and <b>margin</b>. Padding adds space inside the border; margin adds space outside it.</p>',
              example: '.box { padding: 16px; border: 2px solid #333; margin: 12px; }' },
            { id: 'flexbox', title: 'Flexbox Basics',
              content: '<p>Set <code>display: flex</code> on a parent to lay its children in a row. <code>justify-content</code> spaces items along the main axis and <code>align-items</code> aligns them on the cross axis.</p>',
              example: '.row { display: flex; gap: 12px; justify-content: space-between; }' }
          ],
          practice: [
            { q: 'Which selector targets elements with class "card"?', options: ['#card', '.card', 'card', '*card'], answer: 1, explain: 'A dot selects by class name.' },
            { q: 'In the box model, which layer is outermost?', options: ['Content', 'Padding', 'Border', 'Margin'], answer: 3, explain: 'Margin sits outside the border.' },
            { q: 'Which declaration makes an element a flex container?', options: ['display: flex', 'flex: container', 'position: flex', 'layout: flex'], answer: 0, explain: 'display: flex turns on Flexbox layout for the children.' }
          ]
        }
      ],
      quizzes: [
        { id: 'web-quiz', title: 'Web Fundamentals Quiz', description: 'Mixed questions from HTML and CSS.', seconds: 120,
          questions: [
            { q: 'HTML stands for…', options: ['HyperText Markup Language', 'High Tech Modern Language', 'Hyper Transfer Markup Logic', 'Home Tool Markup Language'], answer: 0, explain: 'HyperText Markup Language.' },
            { q: 'Which CSS property changes text colour?', options: ['font-color', 'text-style', 'color', 'foreground'], answer: 2, explain: 'The color property sets text colour.' },
            { q: 'Which tag defines a paragraph?', options: ['<p>', '<para>', '<pg>', '<text>'], answer: 0, explain: '<p> is the paragraph element.' },
            { q: 'What does justify-content do in Flexbox?', options: ['Aligns items along the main axis', 'Sets the font', 'Adds a border', 'Changes z-index'], answer: 0, explain: 'It distributes items along the main axis.' }
          ] }
      ]
    },
    {
      id: 'math', title: 'Everyday Mathematics', icon: '🧮',
      description: 'Percentages and algebra you can use in daily life.',
      chapters: [
        {
          id: 'percentages', title: 'Percentages',
          description: 'Work with percentages for shopping, marks and growth.',
          objectives: ['Understand what percent means', 'Find a percentage of a number', 'Calculate discounts and increases'],
          topics: [
            { id: 'understanding-percent', title: 'Understanding Percent',
              content: '<p>Percent means "out of 100". So 50% = 50/100 = 1/2 = 0.5. To convert a percent to a decimal, divide by 100.</p>',
              example: '25% = 25 ÷ 100 = 0.25' },
            { id: 'percent-of-number', title: 'Percentage of a Number',
              content: '<p>To find a percentage of a number, convert the percent to a decimal and multiply.</p>',
              example: '20% of 150 = 0.20 × 150 = 30' },
            { id: 'discounts', title: 'Discounts and Increases',
              content: '<p>A discount reduces the price: <b>saving = price × percent ÷ 100</b>. Percent increase is <b>(new − old) ÷ old × 100</b>.</p>',
              example: '₹800 with 25% off → saving ₹200, pay ₹600' }
          ],
          practice: [
            { q: 'What is 25% of 200?', options: ['25', '50', '75', '100'], answer: 1, explain: '0.25 × 200 = 50.' },
            { q: 'What is 50% written as a fraction?', options: ['1/4', '1/3', '1/2', '2/3'], answer: 2, explain: '50/100 simplifies to 1/2.' },
            { q: 'A 20% discount on ₹500 saves how much?', options: ['₹20', '₹50', '₹100', '₹200'], answer: 2, explain: '0.20 × 500 = 100.' }
          ]
        },
        {
          id: 'algebra-basics', title: 'Algebra Basics',
          description: 'Use letters for unknown numbers and solve simple equations.',
          objectives: ['Read variables and expressions', 'Combine like terms', 'Solve one-step equations'],
          topics: [
            { id: 'variables', title: 'Variables and Expressions',
              content: '<p>A variable is a letter, like <b>x</b>, that stands for a number. Like terms can be added together: 2x + 3x = 5x.</p>',
              example: '4y + y = 5y' },
            { id: 'simple-equations', title: 'Solving Simple Equations',
              content: '<p>To solve an equation, do the same operation on both sides until the variable is alone.</p>',
              example: 'x + 7 = 12 → x = 12 − 7 → x = 5\n3x = 18 → x = 18 ÷ 3 → x = 6' }
          ],
          practice: [
            { q: 'Solve: x + 7 = 12', options: ['3', '5', '7', '19'], answer: 1, explain: 'Subtract 7 from both sides: x = 5.' },
            { q: 'Solve: 3x = 18', options: ['3', '6', '9', '15'], answer: 1, explain: 'Divide both sides by 3: x = 6.' },
            { q: 'Simplify: 2x + 3x', options: ['5x', '6x', '5x²', 'x⁵'], answer: 0, explain: 'Add the coefficients: 2 + 3 = 5.' }
          ]
        }
      ],
      quizzes: [
        { id: 'math-quiz', title: 'Numbers Quiz', description: 'Percentages and algebra together.', seconds: 120,
          questions: [
            { q: 'What is 10% of 350?', options: ['30', '35', '3.5', '45'], answer: 1, explain: '0.10 × 350 = 35.' },
            { q: 'If 2x − 4 = 10, what is x?', options: ['3', '6', '7', '14'], answer: 2, explain: '2x = 14, so x = 7.' },
            { q: 'A price rises from 50 to 60. What is the percent increase?', options: ['10%', '20%', '25%', '50%'], answer: 1, explain: '(60 − 50) ÷ 50 = 0.20 = 20%.' },
            { q: 'Which value equals 0.75?', options: ['3/4', '2/3', '1/4', '4/5'], answer: 0, explain: '3 ÷ 4 = 0.75.' }
          ] }
      ]
    },
    {
      id: 'science', title: 'General Science', icon: '🔬',
      description: 'Space and the human body explained simply.',
      chapters: [
        {
          id: 'solar-system', title: 'Our Solar System',
          description: 'Meet the Sun, the planets and the Moon.',
          objectives: ['Name the planets in order', 'Compare inner and outer planets', 'Explain how the Moon causes tides'],
          topics: [
            { id: 'sun-planets', title: 'The Sun and Planets',
              content: '<p>The Sun is a star at the centre of our solar system. Eight planets orbit it, in order: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus and Neptune.</p>',
              example: 'Closest to the Sun: Mercury. Largest planet: Jupiter.' },
            { id: 'inner-outer', title: 'Inner vs Outer Planets',
              content: '<p>The four inner planets are small and rocky. The four outer planets are much larger: Jupiter and Saturn are gas giants, Uranus and Neptune are ice giants.</p>',
              example: 'Mars is called the Red Planet because of iron oxide (rust) on its surface.' },
            { id: 'moon-tides', title: 'The Moon and Tides',
              content: '<p>The Moon is Earth\'s natural satellite. Its gravity pulls on the oceans, creating high and low tides about twice a day.</p>',
              example: 'Tides are strongest when the Sun, Earth and Moon line up.' }
          ],
          practice: [
            { q: 'Which planet is closest to the Sun?', options: ['Venus', 'Earth', 'Mercury', 'Mars'], answer: 2, explain: 'Mercury orbits closest to the Sun.' },
            { q: 'Which is the largest planet?', options: ['Saturn', 'Jupiter', 'Neptune', 'Earth'], answer: 1, explain: 'Jupiter is the largest planet.' },
            { q: 'What mainly causes ocean tides?', options: ['Wind', "The Moon's gravity", 'Rain', 'Volcanoes'], answer: 1, explain: "The Moon's gravity pulls the oceans." }
          ]
        },
        {
          id: 'human-body', title: 'Human Body Basics',
          description: 'How the heart and digestive system keep you going.',
          objectives: ['Describe the heart and circulation', 'Explain how digestion works'],
          topics: [
            { id: 'heart', title: 'The Heart and Circulation',
              content: '<p>The heart is a muscle with four chambers that pumps blood around the body. Arteries carry blood away from the heart; veins carry it back.</p>',
              example: 'A resting adult heart beats about 60–100 times per minute.' },
            { id: 'digestion', title: 'The Digestive System',
              content: '<p>Food is broken down in the mouth and stomach. The small intestine absorbs most nutrients into the blood; the large intestine absorbs water.</p>',
              example: 'Path of food: mouth → oesophagus → stomach → small intestine → large intestine.' }
          ],
          practice: [
            { q: 'How many chambers does the human heart have?', options: ['2', '3', '4', '5'], answer: 2, explain: 'Two atria and two ventricles.' },
            { q: 'Where does most nutrient absorption happen?', options: ['Stomach', 'Small intestine', 'Large intestine', 'Oesophagus'], answer: 1, explain: 'The small intestine absorbs most nutrients.' },
            { q: 'Which vessels carry blood away from the heart?', options: ['Veins', 'Arteries', 'Capillaries', 'Nerves'], answer: 1, explain: 'Arteries carry blood away from the heart.' }
          ]
        }
      ],
      quizzes: [
        { id: 'science-quiz', title: 'Science Mix Quiz', description: 'Space and body questions.', seconds: 120,
          questions: [
            { q: 'Which planet is known as the Red Planet?', options: ['Mars', 'Venus', 'Jupiter', 'Mercury'], answer: 0, explain: 'Mars looks red because of iron oxide.' },
            { q: 'Which organ pumps blood?', options: ['Lungs', 'Liver', 'Heart', 'Kidney'], answer: 2, explain: 'The heart pumps blood.' },
            { q: "What is Earth's natural satellite?", options: ['Moon', 'Phobos', 'Titan', 'Europa'], answer: 0, explain: 'The Moon orbits Earth.' },
            { q: 'Which gas do we need to breathe in?', options: ['Nitrogen', 'Oxygen', 'Helium', 'Hydrogen'], answer: 1, explain: 'Our bodies use oxygen.' }
          ] }
      ]
    }
  ],
  tools: [
    { id: 'calculator', title: 'Calculator', icon: '🧮', description: 'Add, subtract, multiply, divide and percent.' },
    { id: 'timer', title: 'Timer', icon: '⏳', description: 'Countdown with start, pause and reset.' },
    { id: 'stopwatch', title: 'Stopwatch', icon: '⏱️', description: 'Measure time with laps.' },
    { id: 'notes', title: 'Notes', icon: '📝', description: 'Write, edit and delete notes saved on this device.' }
  ],
  games: [
    { id: 'memory', title: 'Memory Match', icon: '🧠', bestMode: 'low', unit: 'moves',
      description: 'Flip cards and find all matching pairs.',
      instructions: 'Tap two cards to flip them. If they match they stay open. Find all 6 pairs using as few moves as you can.' },
    { id: 'quicktap', title: 'Quick Tap', icon: '🎯', bestMode: 'high', unit: 'points',
      description: 'Tap the target as many times as you can in 30 seconds.',
      instructions: 'Press Start, then tap the glowing target every time it moves. You have 30 seconds. Each hit is 1 point.' }
  ]
};

/* ===== Extended content: diagrams, new chapters, games. Add more by pushing objects here. ===== */
(function (D) {
  const dg = (w, h, inner, label) => `<svg class="dg" viewBox="0 0 ${w} ${h}" role="img" aria-label="${label}"><defs><marker id="ah" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto"><path d="M0 0L8 4L0 8z" class="ah"/></marker></defs>${inner}</svg>`;
  const tx = (x, y, t, cls) => { const L = String(t).split('|'); return `<text class="${cls || 't'}" x="${x}" y="${y - (L.length - 1) * 7}" text-anchor="middle">${L.map((l, i) => `<tspan x="${x}" dy="${i ? 14 : 0}">${l}</tspan>`).join('')}</text>`; };
  const bx = (x, y, w, h, t, f) => `<rect class="b" x="${x}" y="${y}" width="${w}" height="${h}" rx="10"${f ? ` style="fill:${f}"` : ''}/>${tx(x + w / 2, y + h / 2 + 4, t)}`;
  const ar = (x1, y1, x2, y2) => `<line class="a" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" marker-end="url(#ah)"/>`;
  const flow = (L, label) => {
    const n = L.length; let s = '';
    if (n <= 3) { const bw = 96, g = 34, w = n * bw + (n - 1) * g + 20; L.forEach((t, i) => { const x = 10 + i * (bw + g); s += bx(x, 16, bw, 52, t); if (i < n - 1) s += ar(x + bw + 3, 42, x + bw + g - 3, 42); }); return dg(w, 84, s, label); }
    const bh = 38, g = 26, h = n * (bh + g) - g + 20; L.forEach((t, i) => { const y = 10 + i * (bh + g); s += bx(10, y, 220, bh, t); if (i < n - 1) s += ar(120, y + bh + 2, 120, y + bh + g - 2); }); return dg(240, h, s, label);
  };
  const T = (c, ch, t) => D.categories.find(x => x.id === c).chapters.find(x => x.id === ch).topics.find(x => x.id === t);

  /* --- diagrams --- */
  const boxModel = dg(300, 200, `<rect class="s" x="10" y="10" width="280" height="180" rx="8" stroke-dasharray="5 4"/>${tx(150, 27, 'margin')}<rect class="b" x="40" y="36" width="220" height="128" rx="6" style="fill:rgba(234,179,8,.2)"/>${tx(150, 54, 'border')}<rect class="b" x="60" y="62" width="180" height="84" rx="6" style="fill:rgba(34,197,94,.2)"/>${tx(150, 80, 'padding')}<rect class="b" x="90" y="90" width="120" height="40" rx="6" style="fill:rgba(99,102,241,.35)"/>${tx(150, 115, 'content')}`, 'CSS box model: margin, border, padding, content');
  const dom = dg(320, 175, bx(115, 8, 90, 30, 'html') + ar(140, 40, 80, 66) + ar(180, 40, 240, 66) + bx(35, 68, 90, 30, 'head') + bx(195, 68, 90, 30, 'body') + ar(70, 100, 45, 126) + ar(225, 100, 190, 126) + ar(255, 100, 275, 126) + bx(10, 128, 70, 30, 'title') + bx(150, 128, 70, 30, 'h1') + bx(240, 128, 70, 30, 'p'), 'DOM tree');
  const pct = dg(320, 120, [0, 1, 2, 3, 4].map(i => `<line class="s" x1="${10 + i * 75}" y1="36" x2="${10 + i * 75}" y2="72"/>${tx(10 + i * 75, 28, i * 50, 'ts')}${tx(10 + i * 75, 90, i * 25 + '%', 'ts')}`).join('') + `<rect class="f1" x="10" y="38" width="75" height="32" rx="4"/><rect class="s" x="10" y="38" width="300" height="32" rx="4"/>` + tx(160, 112, '25% of 200 = 50', 'ts'), 'Percentage bar showing 25 percent of 200');
  const shapes = dg(330, 140, `<rect class="b" x="12" y="20" width="90" height="56"/>${tx(57, 52, 'l × w')}${tx(57, 98, 'Area = l × w', 'ts')}${tx(57, 114, 'P = 2(l + w)', 'ts')}<polygon class="b" points="125,76 170,20 215,76"/>${tx(170, 98, 'Area = ½ × b × h', 'ts')}${tx(170, 114, 'P = a + b + c', 'ts')}<circle class="b" cx="283" cy="48" r="30"/><line class="a" x1="283" y1="48" x2="313" y2="48"/>${tx(298, 42, 'r', 'ts')}${tx(283, 98, 'Area = πr²', 'ts')}${tx(283, 114, 'C = 2πr', 'ts')}`, 'Rectangle, triangle and circle formulas');
  const angles = dg(300, 140, `<polygon class="b" points="30,110 200,110 120,25"/>${tx(22, 128, 'A', 'ts')}${tx(210, 128, 'B', 'ts')}${tx(120, 18, 'C', 'ts')}${tx(255, 62, 'A + B + C', 'ts')}${tx(255, 80, '= 180°', 'ts')}`, 'Angles of a triangle add up to 180 degrees');
  const col = ['#9ca3af', '#fbbf24', '#3b82f6', '#ef4444', '#f59e0b', '#eab308', '#22d3ee', '#6366f1'], rad = [3, 5, 5.5, 4, 12, 10, 7, 7];
  const solar = dg(400, 100, `<circle cx="26" cy="46" r="26" fill="#f59e0b"/>${tx(26, 90, 'Sun', 'ts')}` + ['Mer', 'Ven', 'Ear', 'Mar', 'Jup', 'Sat', 'Ura', 'Nep'].map((p, i) => `<circle cx="${80 + i * 45}" cy="46" r="${rad[i]}" style="fill:${col[i]}"/>${tx(80 + i * 45, 90, p, 'ts')}`).join(''), 'Planets in order from the Sun');
  const heart = dg(300, 190, tx(75, 16, 'Right side: to lungs', 'ts') + tx(225, 16, 'Left side: to body', 'ts') + bx(20, 26, 110, 50, 'Right|atrium', 'rgba(59,130,246,.3)') + bx(170, 26, 110, 50, 'Left|atrium', 'rgba(239,68,68,.3)') + bx(20, 110, 110, 50, 'Right|ventricle', 'rgba(59,130,246,.3)') + bx(170, 110, 110, 50, 'Left|ventricle', 'rgba(239,68,68,.3)') + ar(75, 78, 75, 108) + ar(225, 78, 225, 108) + tx(150, 182, 'Blue: low oxygen · Red: high oxygen', 'ts'), 'Four chambers of the heart');
  const photo = dg(340, 210, `<circle cx="300" cy="30" r="16" fill="#f59e0b"/>${ar(288, 44, 240, 80)}${tx(300, 62, 'Sunlight', 'ts')}<ellipse cx="170" cy="115" rx="72" ry="36" style="fill:rgba(34,197,94,.3);stroke:#22c55e;stroke-width:2"/>${tx(170, 118, 'Leaf|(chlorophyll)')}${ar(20, 100, 96, 108)}${tx(48, 90, 'CO₂ from air', 'ts')}${ar(170, 198, 170, 154)}${tx(170, 208, 'Water from roots', 'ts')}${ar(240, 122, 322, 136)}${tx(290, 156, 'O₂ released', 'ts')}${ar(170, 78, 170, 44)}${tx(170, 34, 'Glucose (food)', 'ts')}`, 'Photosynthesis');
  const water = dg(340, 215, `<circle cx="30" cy="30" r="16" fill="#f59e0b"/><rect x="0" y="175" width="340" height="40" style="fill:rgba(59,130,246,.35)"/>${tx(60, 200, 'Sea', 'ts')}<polygon points="215,175 275,95 335,175" style="fill:rgba(148,163,184,.4);stroke:#94a3b8"/><ellipse cx="190" cy="48" rx="46" ry="20" style="fill:rgba(148,163,184,.55)"/>${tx(190, 52, 'Cloud', 'ts')}${ar(80, 168, 80, 90)}${tx(80, 80, 'Evaporation', 'ts')}${tx(150, 84, 'Condensation', 'ts')}${ar(228, 72, 252, 116)}${tx(290, 76, 'Precipitation', 'ts')}${ar(240, 150, 170, 172)}${tx(150, 160, 'Collection', 'ts')}`, 'The water cycle');
  const vals = [128, 64, 32, 16, 8, 4, 2, 1], bits = [0, 1, 0, 0, 1, 1, 0, 1];
  const binary = dg(340, 110, vals.map((v, i) => `<rect class="b" x="${10 + i * 40}" y="34" width="36" height="36" rx="6" style="fill:${bits[i] ? 'rgba(99,102,241,.55)' : 'transparent'}"/>${tx(28 + i * 40, 57, bits[i])}${tx(28 + i * 40, 26, vals[i], 'ts')}`).join('') + tx(170, 96, '64 + 8 + 4 + 1 = 77', 'ts'), 'Binary place values');
  const cs = dg(340, 125, bx(10, 30, 100, 60, 'Client|(your phone)') + bx(230, 30, 100, 60, 'Server|(website)') + ar(112, 48, 228, 48) + tx(170, 40, 'Request', 'ts') + ar(228, 74, 112, 74) + tx(170, 92, 'Response', 'ts'), 'Client and server');
  const words = [['The', 'Article'], ['quick', 'Adjective'], ['fox', 'Noun'], ['runs', 'Verb'], ['fast', 'Adverb']];
  const sentence = dg(370, 90, words.map((w, i) => { const x = 37 + i * 74; return tx(x, 26, w[0], 'tb') + `<line class="a" x1="${x}" y1="34" x2="${x}" y2="52"/><rect class="b" x="${x - 34}" y="54" width="68" height="26" rx="6"/>` + tx(x, 71, w[1], 'ts'); }).join(''), 'Parts of speech in a sentence');
  const circ = 2 * Math.PI * 36, seg = (p, off, c) => `<circle cx="90" cy="90" r="36" fill="none" stroke="${c}" stroke-width="30" stroke-dasharray="${p * circ / 100} ${circ}" stroke-dashoffset="${-off * circ / 100}" transform="rotate(-90 90 90)"/>`;
  const pie = dg(320, 180, seg(50, 0, '#6366f1') + seg(30, 50, '#22d3ee') + seg(20, 80, '#22c55e') + [['#6366f1', '50% Needs', 50], ['#22d3ee', '30% Wants', 90], ['#22c55e', '20% Savings', 130]].map(l => `<rect x="190" y="${l[2] - 10}" width="14" height="14" rx="3" fill="${l[0]}"/><text class="t" x="212" y="${l[2] + 2}">${l[1]}</text>`).join(''), 'Budget pie chart 50 30 20');

  T('web', 'html-basics', 'what-is-html').diagram = flow(['HTML file|(text)', 'Browser|reads it', 'Web page|you see'], 'From HTML to web page');
  T('web', 'css-basics', 'box-model').diagram = boxModel;
  T('math', 'percentages', 'percent-of-number').diagram = pct;
  T('science', 'solar-system', 'sun-planets').diagram = solar;
  T('science', 'human-body', 'heart').diagram = heart;
  T('science', 'human-body', 'digestion').diagram = flow(['Mouth', 'Oesophagus', 'Stomach', 'Small intestine', 'Large intestine'], 'Path of food');
  const cap = { 'what-is-html': 'How a browser turns HTML into a page', 'box-model': 'The four layers of every element', 'percent-of-number': 'Reading a percentage on a bar', 'sun-planets': 'Planets in order from the Sun (not to scale)', 'heart': 'Blood flow through the four chambers', 'digestion': 'Path of food through the body' };
  D.categories.forEach(c => c.chapters.forEach(ch => ch.topics.forEach(t => { if (cap[t.id]) t.caption = cap[t.id]; })));
  D.categories[0].color = '#6366f1'; D.categories[1].color = '#f59e0b'; D.categories[2].color = '#10b981';

  /* --- new chapters in existing categories --- */
  D.categories[0].chapters.push({
    id: 'js-basics', title: 'JavaScript Basics', description: 'Make pages interactive with variables, functions and events.',
    objectives: ['Store values in variables', 'Write a simple function', 'React to a click using the DOM'],
    topics: [
      { id: 'variables-functions', title: 'Variables and Functions', content: '<p>A <b>variable</b> stores a value, such as <code>let score = 10;</code>. A <b>function</b> is a reusable block of code that you call by name.</p>', example: 'let name = "Asha";\nfunction greet(n) {\n  return "Hello, " + n;\n}\nconsole.log(greet(name)); // Hello, Asha' },
      { id: 'dom-events', title: 'The DOM and Events', caption: 'The page as a tree of elements', diagram: dom, content: '<p>The <b>DOM</b> is a tree of objects that represents your page. JavaScript can change any part of the tree and react to <b>events</b> such as clicks.</p>', example: 'document.querySelector("button")\n  .addEventListener("click", () =&gt; {\n    alert("Clicked!");\n  });' }
    ],
    practice: [
      { q: 'Which keyword declares a variable whose value can change?', options: ['let', 'def', 'dim', 'int'], answer: 0, explain: '"let" declares a changeable variable in JavaScript.' },
      { q: 'What does addEventListener do?', options: ['Draws an image', 'Runs code when an event like a click happens', 'Creates a variable', 'Deletes the page'], answer: 1, explain: 'It waits for an event and then runs your function.' },
      { q: 'The DOM is best described as…', options: ['A tree of page elements', 'A database', 'A CSS file', 'A browser plugin'], answer: 0, explain: 'The DOM models the page as a tree.' }
    ]
  });
  D.categories[1].chapters.push({
    id: 'geometry', title: 'Geometry Basics', description: 'Shapes, area, perimeter and angles.',
    objectives: ['Tell area from perimeter', 'Use formulas for rectangles, triangles and circles', 'Use the triangle angle sum'],
    topics: [
      { id: 'perimeter-area', title: 'Perimeter and Area', caption: 'Key formulas', diagram: shapes, content: '<p><b>Perimeter</b> is the distance around a shape. <b>Area</b> is the space inside it, measured in square units.</p>', example: 'Rectangle 8 cm × 5 cm\nArea = 8 × 5 = 40 cm²\nPerimeter = 2(8 + 5) = 26 cm' },
      { id: 'angles', title: 'Angles in a Triangle', caption: 'The three angles add up to 180°', diagram: angles, content: '<p>The three angles of any triangle add up to <b>180°</b>. A right angle is 90° and a straight line is 180°.</p>', example: 'A = 50°, B = 60°\nC = 180 − (50 + 60) = 70°' }
    ],
    practice: [
      { q: 'What is the area of a rectangle 6 units by 4 units?', options: ['10', '20', '24', '48'], answer: 2, explain: '6 × 4 = 24.' },
      { q: 'The angles of a triangle add up to…', options: ['90°', '180°', '270°', '360°'], answer: 1, explain: 'Always 180°.' },
      { q: 'Which formula gives the area of a circle?', options: ['2πr', 'πr²', 'πd', 'r²/2'], answer: 1, explain: 'Area = πr².' }
    ]
  });
  D.categories[2].chapters.push({
    id: 'photosynthesis', title: 'Photosynthesis', description: 'How plants turn light into food.',
    objectives: ['List what plants need for photosynthesis', 'Name the products', 'Explain why it matters'],
    topics: [
      { id: 'how-plants-eat', title: 'How Plants Make Food', caption: 'Inputs and outputs of a leaf', diagram: photo, content: '<p>Inside leaves, <b>chloroplasts</b> use sunlight to turn carbon dioxide and water into <b>glucose</b> (food) and <b>oxygen</b>.</p>', example: 'carbon dioxide + water --(light)--&gt; glucose + oxygen' },
      { id: 'why-it-matters', title: 'Why It Matters', content: '<p>Photosynthesis feeds plants and, through food chains, almost every other living thing. It also supplies the oxygen we breathe and removes carbon dioxide from the air.</p>', example: 'Forests and ocean plants produce much of the oxygen we breathe.' }
    ],
    practice: [
      { q: 'Which gas do plants take in for photosynthesis?', options: ['Oxygen', 'Carbon dioxide', 'Nitrogen', 'Helium'], answer: 1, explain: 'Plants absorb CO₂ from the air.' },
      { q: 'Where does photosynthesis mainly happen?', options: ['Roots', 'Chloroplasts in leaves', 'Bark', 'Seeds only'], answer: 1, explain: 'Chloroplasts contain chlorophyll.' },
      { q: 'Which gas do plants release?', options: ['Oxygen', 'Methane', 'Smoke', 'Hydrogen'], answer: 0, explain: 'Oxygen is a by-product.' }
    ]
  });
  D.categories[2].chapters.push({
    id: 'water-cycle', title: 'The Water Cycle', description: 'How water moves between sea, sky and land.',
    objectives: ['Name the four stages', 'Explain how clouds form', 'Know how much water is fresh'],
    topics: [
      { id: 'four-stages', title: 'Four Stages', caption: 'Water keeps moving in a cycle', diagram: water, content: '<ul><li><b>Evaporation:</b> heat turns liquid water into vapour.</li><li><b>Condensation:</b> vapour cools and forms clouds.</li><li><b>Precipitation:</b> rain, snow or hail falls.</li><li><b>Collection:</b> water flows back to rivers and seas.</li></ul>', example: 'A puddle that disappears on a sunny day is evaporation.' },
      { id: 'water-on-earth', title: 'Water on Earth', content: '<p>About 71% of Earth\'s surface is covered by water. Most of it is salty ocean water, and only a small part is fresh water, much of which is frozen in ice.</p>', example: "Only about 3% of Earth's water is fresh water." }
    ],
    practice: [
      { q: 'Which stage turns liquid water into vapour?', options: ['Condensation', 'Evaporation', 'Precipitation', 'Collection'], answer: 1, explain: 'Heat causes evaporation.' },
      { q: 'Clouds form by…', options: ['Evaporation', 'Condensation', 'Erosion', 'Melting'], answer: 1, explain: 'Vapour condenses into tiny droplets.' },
      { q: 'Rain and snow are examples of…', options: ['Precipitation', 'Evaporation', 'Collection', 'Condensation'], answer: 0, explain: 'Water falling from clouds is precipitation.' }
    ]
  });

  /* --- new categories --- */
  D.categories.push({
    id: 'cs', title: 'Computer Science', icon: '💾', color: '#06b6d4', description: 'How computers and the internet work.',
    chapters: [
      { id: 'how-computers-work', title: 'How Computers Work', description: 'Input, processing, output and the binary system.', objectives: ['Explain input, process, output', 'Convert a binary number to decimal'],
        topics: [
          { id: 'ipo', title: 'Input, Process, Output', caption: 'The basic cycle of every computer', diagram: flow(['Input|keyboard', 'CPU|processes', 'Output|screen'], 'Input process output'), content: '<p>A computer takes <b>input</b> (keyboard, touch), the <b>CPU</b> processes it using programs and <b>memory</b>, and the result is shown as <b>output</b> (screen, sound).</p>', example: 'Tap a key (input) → CPU picks the letter (process) → letter appears (output)' },
          { id: 'binary', title: 'Binary Numbers', caption: 'Each position is worth double the one on its right', diagram: binary, content: '<p>Computers store everything as <b>bits</b>, which are 0 or 1. Eight bits make one <b>byte</b>. Add the place values of the 1s to get the decimal number.</p>', example: '01001101 = 64 + 8 + 4 + 1 = 77' }
        ],
        practice: [
          { q: 'What is the brain of the computer?', options: ['RAM', 'CPU', 'Monitor', 'Mouse'], answer: 1, explain: 'The CPU carries out instructions.' },
          { q: 'How many bits are in one byte?', options: ['4', '8', '16', '32'], answer: 1, explain: '1 byte = 8 bits.' },
          { q: 'Which one is an input device?', options: ['Speaker', 'Monitor', 'Keyboard', 'Printer'], answer: 2, explain: 'A keyboard sends data in.' }
        ] },
      { id: 'internet', title: 'The Internet', description: 'Clients, servers, IP addresses and DNS.', objectives: ['Describe the client-server model', 'Explain what DNS does'],
        topics: [
          { id: 'client-server', title: 'Clients and Servers', caption: 'Every page load is a request and a response', diagram: cs, content: '<p>Your phone or laptop is the <b>client</b>. It sends a <b>request</b> to a <b>server</b>, a computer that stores websites, and the server sends back a <b>response</b>.</p>', example: 'Opening NEXORA asks the GitHub server for index.html.' },
          { id: 'dns', title: 'IP Addresses and DNS', caption: 'DNS turns a name into an address', diagram: flow(['You type|nexora.app', 'DNS finds|the IP address', 'Server sends|the page'], 'DNS lookup'), content: '<p>Every device on the internet has an <b>IP address</b>. People remember names, so <b>DNS</b> translates a name into the matching IP address.</p>', example: 'example.com → 93.184.216.34 (an example address)' }
        ],
        practice: [
          { q: 'What does a server do?', options: ['Sends requested data', 'Prints pages', 'Charges the battery', 'Draws icons only'], answer: 0, explain: 'Servers respond to requests.' },
          { q: 'DNS translates…', options: ['Names into IP addresses', 'Video into audio', 'Text into images', 'Passwords into codes'], answer: 0, explain: 'DNS is the internet phone book.' },
          { q: 'Your phone browser is a…', options: ['Server', 'Client', 'Router', 'Cable'], answer: 1, explain: 'It requests pages.' }
        ] }
    ],
    quizzes: [{ id: 'cs-quiz', title: 'Tech Basics Quiz', description: 'Computers and the internet.', seconds: 120, questions: [
      { q: 'Binary uses which digits?', options: ['0 and 1', '1 and 2', '0 to 9', 'A and B'], answer: 0, explain: 'Only 0 and 1.' },
      { q: 'CPU stands for…', options: ['Central Processing Unit', 'Computer Personal Unit', 'Central Program Utility', 'Core Power Unit'], answer: 0, explain: 'Central Processing Unit.' },
      { q: 'A browser asks a server for…', options: ['Web pages and data', 'Electricity', 'Paper', 'Passwords only'], answer: 0, explain: 'It requests pages and files.' },
      { q: 'Which is an output device?', options: ['Mouse', 'Keyboard', 'Monitor', 'Scanner'], answer: 2, explain: 'A monitor shows results.' }] }]
  });
  D.categories.push({
    id: 'english', title: 'English Skills', icon: '📚', color: '#ec4899', description: 'Grammar and punctuation for clear writing.',
    chapters: [
      { id: 'parts-of-speech', title: 'Parts of Speech', description: 'Nouns, verbs, adjectives and adverbs.', objectives: ['Spot nouns and verbs', 'Tell adjectives from adverbs'],
        topics: [
          { id: 'noun-verb', title: 'Nouns and Verbs', content: '<p>A <b>noun</b> names a person, place or thing. A <b>verb</b> shows an action or a state.</p>', example: 'Riya (noun) reads (verb) a book (noun).' },
          { id: 'adj-adv', title: 'Adjectives and Adverbs', caption: 'Each word has a job', diagram: sentence, content: '<p>An <b>adjective</b> describes a noun. An <b>adverb</b> describes a verb, an adjective or another adverb, and often ends in -ly.</p>', example: 'The quick fox runs fast.' }
        ],
        practice: [
          { q: 'Which word is the verb in "Sam plays cricket"?', options: ['Sam', 'plays', 'cricket', 'None'], answer: 1, explain: '"plays" is the action.' },
          { q: 'An adjective describes a…', options: ['Noun', 'Full stop', 'Comma', 'Paragraph'], answer: 0, explain: 'Adjectives describe nouns.' },
          { q: 'In "She sings loudly", "loudly" is a(n)…', options: ['Noun', 'Adjective', 'Adverb', 'Pronoun'], answer: 2, explain: 'It describes how she sings.' }
        ] },
      { id: 'punctuation', title: 'Punctuation', description: 'Stops, commas and apostrophes.', objectives: ['End sentences correctly', 'Use apostrophes properly'],
        topics: [
          { id: 'end-marks', title: 'Full Stops, Commas and Question Marks', content: '<p>Use a <b>full stop</b> to end a statement, a <b>question mark</b> to end a question and an <b>exclamation mark</b> for strong feeling. Commas separate items in a list.</p>', example: 'I bought apples, bananas and mangoes. Did you like them?' },
          { id: 'apostrophes', title: 'Apostrophes', content: "<p>Use an apostrophe for <b>contractions</b> (don't = do not) and for <b>possession</b> (Riya's bag). Never use one to make a plural. Note: <i>it's</i> means \"it is\", while <i>its</i> shows ownership.</p>", example: "It's Sam's book.\nThe dog wagged its tail." }
        ],
        practice: [
          { q: 'Which sentence is a question?', options: ['You are late.', 'Are you late?', 'Be late!', 'Late you are.'], answer: 1, explain: 'It asks something and ends with ?.' },
          { q: 'What is the contraction of "do not"?', options: ['dont', "don't", "do'nt", "dont'"], answer: 1, explain: "The apostrophe replaces the o." },
          { q: 'Which shows possession?', options: ["Riya's bag", 'Riyas bag', "Riya bag's", "Riyas's bag'"], answer: 0, explain: "'s shows the bag belongs to Riya." }
        ] }
    ],
    quizzes: [{ id: 'english-quiz', title: 'Grammar Quiz', description: 'Parts of speech and punctuation.', seconds: 120, questions: [
      { q: 'Which word is a noun?', options: ['Quickly', 'Happiness', 'Run', 'Blue'], answer: 1, explain: 'Happiness names a feeling.' },
      { q: 'Which sentence needs a question mark?', options: ['Where do you live', 'Close the door', 'What a day', 'I like tea'], answer: 0, explain: 'It asks a question.' },
      { q: 'Choose the correct word: The cat licked ___ paw.', options: ['its', "it's", "its'", "it is's"], answer: 0, explain: '"its" shows ownership.' },
      { q: 'Which word is the adverb in "He speaks clearly"?', options: ['He', 'speaks', 'clearly', 'None'], answer: 2, explain: 'It describes how he speaks.' }] }]
  });
  D.categories.push({
    id: 'money', title: 'Money Skills', icon: '💰', color: '#22c55e', description: 'Budgeting and simple interest made easy.',
    chapters: [
      { id: 'budgeting', title: 'Budgeting', description: 'Plan where your money goes.', objectives: ['Separate needs from wants', 'Apply the 50/30/20 rule'],
        topics: [
          { id: 'needs-wants', title: 'Needs vs Wants', content: '<p><b>Needs</b> are things you must have, such as food, shelter and transport to work or school. <b>Wants</b> are extras, such as games or luxury items.</p>', example: 'Rent = need. New game console = want.' },
          { id: 'rule-50-30-20', title: 'The 50/30/20 Rule', caption: 'A simple way to split income', diagram: pie, content: '<p>Split your income into <b>50% needs</b>, <b>30% wants</b> and <b>20% savings</b>. It is a starting point you can adjust.</p>', example: 'Income ₹20,000 → needs ₹10,000, wants ₹6,000, savings ₹4,000' }
        ],
        practice: [
          { q: 'Which of these is a need?', options: ['Video game', 'Food', 'Designer shoes', 'Movie ticket'], answer: 1, explain: 'Food is essential.' },
          { q: 'In the 50/30/20 rule, how much goes to savings?', options: ['50%', '30%', '20%', '10%'], answer: 2, explain: '20% is for savings.' },
          { q: 'What is 20% of ₹10,000?', options: ['₹200', '₹2,000', '₹1,000', '₹5,000'], answer: 1, explain: '0.20 × 10,000 = 2,000.' }
        ] },
      { id: 'simple-interest', title: 'Simple Interest', description: 'How savings and loans grow over time.', objectives: ['Use the simple interest formula', 'Find the total amount'],
        topics: [
          { id: 'si-formula', title: 'The Formula', caption: 'Money grows from principal to amount', diagram: flow(['Principal|start money', 'Interest|P×R×T÷100', 'Amount|P + interest'], 'Simple interest'), content: '<p>Simple interest: <b>I = P × R × T ÷ 100</b>, where P is the principal, R is the yearly rate in percent and T is time in years.</p>', example: 'P = ₹1,000, R = 5%, T = 2\nI = 1000 × 5 × 2 ÷ 100 = ₹100' },
          { id: 'si-examples', title: 'Worked Examples', content: '<p>The total <b>Amount = Principal + Interest</b>. First find the interest, then add it to the principal.</p>', example: 'P = ₹5,000, R = 8%, T = 3\nI = 5000 × 8 × 3 ÷ 100 = ₹1,200\nAmount = ₹6,200' }
        ],
        practice: [
          { q: 'Simple interest on ₹2,000 at 10% for 2 years?', options: ['₹200', '₹400', '₹500', '₹2,400'], answer: 1, explain: '2000 × 10 × 2 ÷ 100 = 400.' },
          { q: 'Amount equals…', options: ['P − I', 'P + I', 'P × I', 'P ÷ I'], answer: 1, explain: 'Principal plus interest.' },
          { q: 'In the formula, R stands for…', options: ['Rate of interest', 'Return', 'Ratio', 'Range'], answer: 0, explain: 'R is the rate per year.' }
        ] }
    ],
    quizzes: [{ id: 'money-quiz', title: 'Money Quiz', description: 'Budgeting and interest.', seconds: 120, questions: [
      { q: 'What is 50% of ₹800?', options: ['₹400', '₹80', '₹200', '₹500'], answer: 0, explain: 'Half of 800 is 400.' },
      { q: 'How much of income goes to savings in 50/30/20?', options: ['50%', '30%', '20%', '5%'], answer: 2, explain: '20%.' },
      { q: 'Simple interest on ₹1,000 at 5% for 1 year?', options: ['₹5', '₹50', '₹500', '₹1,000'], answer: 1, explain: '1000 × 5 × 1 ÷ 100 = 50.' },
      { q: 'Which is a want?', options: ['Rent', 'Groceries', 'Latest gaming console', 'Electricity bill'], answer: 2, explain: 'It is not essential.' }] }]
  });

  /* --- tools --- */
  D.tools.push({ id: 'converter', title: 'Unit Converter', icon: '📏', description: 'Convert length, weight and temperature.' });

  /* --- game data banks --- */
  D.banks = {
    sciWords: ['planet', 'gravity', 'oxygen', 'energy', 'magnet', 'carbon', 'nucleus', 'protein', 'climate', 'volcano', 'glacier', 'fossil'],
    techWords: ['browser', 'network', 'keyboard', 'program', 'internet', 'server', 'python', 'coding', 'website', 'laptop', 'memory', 'router'],
    tfSci: [['The Sun is a star.', true], ['Water boils at 100 °C at sea level.', true], ['Sound travels faster than light.', false], ['Plants release oxygen during photosynthesis.', true], ['The human heart has three chambers.', false], ['Mars is called the Blue Planet.', false], ['Diamonds are made of carbon.', true], ['The Moon makes its own light.', false], ['Adults have 206 bones.', true], ['Lightning is hotter than the surface of the Sun.', true]],
    tfTech: [['CPU stands for Central Processing Unit.', true], ['HTML describes the structure of web pages.', true], ['One byte contains 8 bits.', true], ['RAM keeps your files when the power is off.', false], ['A URL is the address of a web page.', true], ['CSS is used to style web pages.', true], ['Binary uses the digits 0 to 9.', false], ['Wi-Fi always needs a cable.', false], ['A browser is a type of software.', true], ['The internet and the Web mean exactly the same thing.', false]],
    capitals: [['India', 'New Delhi'], ['Japan', 'Tokyo'], ['France', 'Paris'], ['Australia', 'Canberra'], ['Canada', 'Ottawa'], ['Brazil', 'Brasília'], ['Egypt', 'Cairo'], ['Germany', 'Berlin'], ['Italy', 'Rome'], ['Kenya', 'Nairobi'], ['Spain', 'Madrid'], ['Nepal', 'Kathmandu'], ['Turkey', 'Ankara'], ['Argentina', 'Buenos Aires']],
    odd: [[['Apple', 'Mango', 'Banana'], 'Carrot'], [['Circle', 'Square', 'Triangle'], 'Cube'], [['Mercury', 'Venus', 'Mars'], 'Moon'], [['HTML', 'CSS', 'JavaScript'], 'Keyboard'], [['Dog', 'Cat', 'Horse'], 'Eagle'], [['Piano', 'Guitar', 'Violin'], 'Hammer'], [['Paris', 'Rome', 'Tokyo'], 'Nile'], [['Lion', 'Tiger', 'Leopard'], 'Shark']],
    elements: [['H', 'Hydrogen'], ['O', 'Oxygen'], ['Fe', 'Iron'], ['Au', 'Gold'], ['Na', 'Sodium'], ['C', 'Carbon']],
    sentences: ['Practice makes progress every single day.', 'The quick brown fox jumps over the lazy dog.', 'Learning to code is like learning a new language.', 'Small steps every day lead to big results.']
  };
  const G = (id, icon, title, cat, description, instructions, bestMode, unit) => ({ id, icon, title, cat, description, instructions, bestMode: bestMode || 'high', unit: unit || 'points' });
  D.games = [
    G('add', '➕', 'Addition Blitz', 'Math', 'Solve as many sums as you can in 45 seconds.', 'Pick the correct answer for each sum. Each correct answer is 1 point. You have 45 seconds.'),
    G('sub', '➖', 'Subtraction Sprint', 'Math', 'Fast subtraction against the clock.', 'Pick the correct answer. 45 seconds, 1 point per correct answer.'),
    G('mult', '✖️', 'Times Table Rush', 'Math', 'Multiplication facts from 2 to 12.', 'Pick the correct product. 45 seconds, 1 point per correct answer.'),
    G('div', '➗', 'Division Dash', 'Math', 'Exact division, no remainders.', 'Pick the correct quotient. 45 seconds, 1 point per correct answer.'),
    G('mixmath', '🧮', 'Mixed Math Mania', 'Math', 'All four operations mixed together.', 'Answer sums, differences, products and quotients. 60 seconds; a wrong answer costs 1 point.'),
    G('scramble-sci', '🔤', 'Science Word Scramble', 'Words', 'Unscramble science words.', 'Letters are mixed up. Choose the correct word. 60 seconds, 1 point each.'),
    G('scramble-tech', '💻', 'Tech Word Scramble', 'Words', 'Unscramble technology words.', 'Letters are mixed up. Choose the correct word. 60 seconds, 1 point each.'),
    G('tf-sci', '🧪', 'Science True or False', 'Knowledge', 'Decide if each science fact is true.', 'Read the statement and choose True or False. 10 questions, 1 point each.'),
    G('tf-tech', '🖥️', 'Tech True or False', 'Knowledge', 'Test your technology knowledge.', 'Read the statement and choose True or False. 10 questions, 1 point each.'),
    G('capitals', '🌍', 'Capital Quiz', 'Knowledge', 'Match countries with their capitals.', 'Choose the capital city. 10 questions, 1 point each.'),
    G('sequence', '🔢', 'Number Sequence', 'Brain', 'Find the next number in the pattern.', 'Look at the pattern and pick the next number. 60 seconds, 1 point each.'),
    G('oddone', '🧩', 'Odd One Out', 'Brain', 'Spot the item that does not belong.', 'Three items share something. Pick the one that does not. 8 questions.'),
    G('stroop', '🎨', 'Colour Clash', 'Brain', 'Pick the ink colour, not the word.', 'A colour name appears in a different ink. Choose the colour of the INK. 30 seconds.'),
    G('hilo', '📈', 'Higher or Lower', 'Brain', 'Guess if the next number is higher or lower.', 'You see a number from 1 to 99. Guess whether the next one is higher or lower. 40 seconds.'),
    G('memory', '🧠', 'Memory Match', 'Brain', 'Flip cards and find all pairs.', 'Tap two cards to flip them. Matching cards stay open. Find all 6 pairs in as few moves as you can.', 'low', 'moves'),
    G('elements', '⚗️', 'Element Match', 'Knowledge', 'Match chemical symbols to names.', 'Flip two cards. A match is a symbol and its element name, like Fe and Iron. Use as few moves as you can.', 'low', 'moves'),
    G('quicktap', '🎯', 'Quick Tap', 'Reflex', 'Tap the moving target for 30 seconds.', 'Press Start, then tap the target every time it moves. Each hit is 1 point.'),
    G('reaction', '⚡', 'Reaction Test', 'Reflex', 'How fast can you react?', 'Wait until the box turns green, then tap. Three rounds; your score is the average time. Lower is better.', 'low', 'ms'),
    G('simon', '🎵', 'Pattern Memory', 'Brain', 'Repeat the growing colour pattern.', 'Watch the pads light up, then tap them in the same order. Each level adds one step.', 'high', 'levels'),
    G('whack', '🐹', 'Whack-a-Mole', 'Reflex', 'Tap the mole before it hides.', 'Moles pop up randomly. Tap each one. 30 seconds, 1 point per mole.'),
    G('tictactoe', '❌', 'Tic-Tac-Toe', 'Classic', 'Beat the computer at noughts and crosses.', 'You are ❌. Get three in a row. Win = 3 points, draw = 1, loss = 0.'),
    G('guess', '🔮', 'Number Guess', 'Classic', 'Find the secret number from 1 to 100.', 'You have 7 tries. After each guess you learn if the secret is higher or lower. Fewer tries = more points.'),
    G('hangman', '🪢', 'Hangman', 'Words', 'Guess the hidden word letter by letter.', 'Tap letters to guess. You can miss 6 times. Win with more lives left for a higher score.'),
    G('slide', '🧱', 'Sliding Puzzle', 'Classic', 'Slide tiles into order 1 to 8.', 'Tap a tile next to the empty space to slide it. Put the tiles in order using as few moves as possible.', 'low', 'moves'),
    G('typing', '⌨️', 'Typing Speed', 'Words', 'Type the sentence as fast as you can.', 'The timer starts when you type the first letter. Type the sentence exactly. Your score is words per minute.', 'high', 'WPM')
  ];
})(NEXORA_DATA);
