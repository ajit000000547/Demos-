/* NEXORA features: storage, toast, modal, sound, quiz engine, tools, games */
window.NX = (function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const go = h => { location.hash = h; };
  const fmt = s => String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  let cleaners = [];
  const onCleanup = f => cleaners.push(f);
  const cleanup = () => { cleaners.forEach(f => { try { f(); } catch (e) { } }); cleaners = []; };

  /* ---------- Storage ---------- */
  const KEY = 'nexora_v1';
  const defaults = () => ({ completedChapters: [], completedTopics: [], quizScores: {}, practiceBest: {}, recent: [], last: null, settings: { theme: null, anim: true, sound: true }, notes: [], games: {}, xp: 0, awarded: [], streak: { last: '', count: 0 }, bookmarks: [] });
  let storageOk = true, data = defaults();
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const d = JSON.parse(raw), b = defaults();
      if (d && typeof d === 'object') {
        Object.keys(b).forEach(k => { if (d[k] != null && Array.isArray(d[k]) === Array.isArray(b[k]) && typeof d[k] === typeof b[k]) b[k] = d[k]; });
        if (typeof d.last === 'string') b.last = d.last;
      }
      b.settings = Object.assign(defaults().settings, b.settings);
      data = b;
    }
  } catch (e) { storageOk = false; }
  const Store = {
    get d() { return data; },
    get ok() { return storageOk; },
    save() { try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) { storageOk = false; } },
    resetProgress() { data = Object.assign(defaults(), { settings: data.settings, notes: data.notes }); Store.save(); },
    clearAll() { try { localStorage.removeItem(KEY); } catch (e) { storageOk = false; } data = defaults(); }
  };

  /* ---------- Toast, sound, modal ---------- */
  function toast(msg, type) {
    const r = $('#toasts'); if (!r) return;
    const t = document.createElement('div'); t.className = 'toast ' + (type || 'info'); t.textContent = msg; r.appendChild(t);
    setTimeout(() => t.remove(), 3200);
  }
  let ac = null;
  function beep(f, d) {
    if (!data.settings.sound) return;
    try { ac = ac || new (window.AudioContext || window.webkitAudioContext)(); const o = ac.createOscillator(), g = ac.createGain(); o.frequency.value = f || 660; g.gain.value = 0.05; o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + (d || 0.12)); } catch (e) { }
  }
  let lastFocus = null;
  function closeModal() { const r = $('#modalRoot'); if (r) r.innerHTML = ''; if (lastFocus && lastFocus.focus) try { lastFocus.focus(); } catch (e) { } lastFocus = null; }
  function modal(o) {
    const r = $('#modalRoot'); if (!r) return null;
    lastFocus = document.activeElement;
    r.innerHTML = `<div class="overlay"><div class="dialog" role="dialog" aria-modal="true" aria-label="${esc(o.title)}"><h2>${esc(o.title)}</h2><div class="dbody">${o.body || ''}</div><div class="dactions">${(o.actions || [{ label: 'Close' }]).map((a, i) => `<button class="btn ${a.cls || ''}" data-mi="${i}">${esc(a.label)}</button>`).join('')}</div></div></div>`;
    const ov = $('.overlay', r), acts = o.actions || [{ label: 'Close' }];
    ov.addEventListener('click', e => { if (e.target === ov) closeModal(); });
    $$('[data-mi]', r).forEach(b => b.addEventListener('click', () => { const a = acts[+b.dataset.mi]; closeModal(); if (a.onClick) a.onClick(); }));
    const first = $('input,button', r); if (first) first.focus();
    return $('.dialog', r);
  }
  const confirmBox = (title, msg, label, cb) => modal({ title, body: `<p>${esc(msg)}</p>`, actions: [{ label: 'Cancel' }, { label, cls: 'danger', onClick: cb }] });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && $('#modalRoot .overlay')) closeModal(); });

  /* ---------- Quiz / practice engine ---------- */
  let qTimer = null;
  function startQuiz(cfg) {
    clearInterval(qTimer);
    const view = $('#view');
    const qs = (cfg.qs || []).filter(q => q && q.q && Array.isArray(q.options) && q.options.length > 1 && Number.isInteger(q.answer) && q.answer >= 0 && q.answer < q.options.length);
    if (!qs.length) { view.innerHTML = `<div class="page"><div class="empty"><div class="big">🗒️</div><h2>No questions available</h2><p>This section has no valid questions yet.</p><button class="btn primary" data-go="${esc(cfg.back)}">Go back</button></div></div>`; return; }
    const practice = cfg.mode === 'practice';
    const st = { i: 0, a: qs.map(() => null), done: false, left: cfg.seconds || 0 };
    const score = () => st.a.reduce((s, a, i) => s + (a === qs[i].answer ? 1 : 0), 0);
    const answered = () => st.a.filter(a => a !== null).length;

    function draw() {
      if (st.done) return;
      const q = qs[st.i], sel = st.a[st.i], locked = practice && sel !== null, last = st.i === qs.length - 1;
      view.innerHTML = `<div class="page"><section class="card quiz">
        <div class="q-top"><button class="btn ghost sm" data-quit>✕ Exit</button><span class="pill">Question ${st.i + 1} of ${qs.length}</span>${practice ? `<span class="pill">Score ${score()}</span>` : ''}${cfg.seconds ? `<span class="pill" id="qtime">⏱ ${fmt(st.left)}</span>` : ''}</div>
        <div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(answered() / qs.length * 100)}"><i style="width:${answered() / qs.length * 100}%"></i></div>
        <h2 class="q-text">${esc(q.q)}</h2>
        <div class="opts">${q.options.map((o, k) => {
          let c = 'opt';
          if (locked) { if (k === q.answer) c += ' correct'; else if (k === sel) c += ' wrong'; } else if (sel === k) c += ' selected';
          return `<button class="${c}" data-opt="${k}" ${locked ? 'disabled' : ''} aria-pressed="${sel === k}"><b>${'ABCDEF'[k]}</b><span>${esc(o)}</span></button>`;
        }).join('')}</div>
        ${locked ? `<div class="feedback ${sel === q.answer ? 'ok' : 'bad'}" role="status">${sel === q.answer ? '✅ Correct!' : '❌ Not quite.'} ${esc(q.explain || '')}</div>` : ''}
        <div class="q-nav"><button class="btn" data-prev ${st.i === 0 ? 'disabled' : ''}>← Previous</button>
        <button class="btn primary" data-next ${practice && sel === null ? 'disabled' : ''}>${last ? (practice ? 'Finish' : 'Submit') : 'Next →'}</button></div>
      </section></div>`;
      $$('[data-opt]', view).forEach(b => b.onclick = () => {
        if (st.done || (practice && st.a[st.i] !== null)) return;
        st.a[st.i] = +b.dataset.opt;
        if (practice) beep(st.a[st.i] === q.answer ? 740 : 220);
        draw();
      });
      $('[data-prev]', view).onclick = () => { if (st.i > 0) { st.i--; draw(); } };
      $('[data-next]', view).onclick = () => {
        if (!last) { st.i++; draw(); return; }
        const miss = qs.length - answered();
        if (miss > 0 && !practice) confirmBox('Submit quiz?', `You left ${miss} question(s) unanswered. Submit anyway?`, 'Submit', () => finish(false));
        else finish(false);
      };
      $('[data-quit]', view).onclick = () => confirmBox('Exit?', 'Your answers for this attempt will be lost.', 'Exit', () => { clearInterval(qTimer); NX.go(cfg.back); });
    }

    function finish(auto) {
      if (st.done) return;
      st.done = true; clearInterval(qTimer); closeModal();
      const sc = score(), total = qs.length, pct = Math.round(sc / total * 100);
      if (cfg.onFinish) { try { cfg.onFinish(sc, total, pct); } catch (e) { } }
      beep(pct >= 60 ? 880 : 240, 0.25);
      const msg = pct === 100 ? 'Perfect score! 🏆' : pct >= 70 ? 'Great work! 🎉' : pct >= 40 ? 'Good try – review and go again.' : 'Keep practising – you will get there.';
      view.innerHTML = `<div class="page"><section class="card result">
        <div class="ring" style="--p:${pct}"><span>${pct}%</span></div>
        <h2>${auto ? "Time's up! " : ''}${esc(cfg.title)} complete</h2>
        <p class="muted">${msg}</p>
        <div class="stats3"><div><b>${sc}</b><small>Correct</small></div><div><b>${total - sc}</b><small>Incorrect</small></div><div><b>${pct}%</b><small>Score</small></div></div>
        <div class="row"><button class="btn primary" data-retry>↻ Restart</button><button class="btn" data-go="${esc(cfg.back)}">Back</button></div>
        <h3 class="left">Review</h3>
        <ol class="review">${qs.map((q, i) => { const a = st.a[i], ok = a === q.answer; return `<li class="${ok ? 'ok' : 'bad'}"><b>${esc(q.q)}</b><br>Your answer: ${a === null ? '<i>skipped</i>' : esc(q.options[a])} ${ok ? '✅' : '❌'}${ok ? '' : `<br>Correct: ${esc(q.options[q.answer])}`}</li>`; }).join('')}</ol>
      </section></div>`;
      $('[data-retry]', view).onclick = () => startQuiz(cfg);
    }

    if (cfg.seconds) {
      qTimer = setInterval(() => {
        st.left--; const t = $('#qtime'); if (t) t.textContent = '⏱ ' + fmt(Math.max(0, st.left));
        if (st.left <= 0) finish(true);
      }, 1000);
      onCleanup(() => clearInterval(qTimer));
    }
    draw();
  }

  /* ---------- Tools ---------- */
  const tools = {};
  tools.calculator = root => {
    let cur = '0', prev = null, op = null, fresh = false;
    const keys = ['C', '⌫', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '−', '1', '2', '3', '+', '0', '.', '='];
    root.innerHTML = `<div class="card tool calc"><div class="cdisp" id="cdisp" role="status" aria-live="polite">0</div><div class="ckeys">${keys.map(k => `<button class="ck ${'÷×−+'.includes(k) ? 'op' : ''} ${k === '=' ? 'eq' : ''} ${k === '0' ? 'zero' : ''}" data-k="${k}" aria-label="${k}">${k}</button>`).join('')}</div></div>`;
    const disp = $('#cdisp', root), upd = () => { disp.textContent = cur; };
    const calc = (a, b, o) => { a = parseFloat(a); b = parseFloat(b); let r = o === '+' ? a + b : o === '−' ? a - b : o === '×' ? a * b : (b === 0 ? NaN : a / b); return isFinite(r) ? String(+r.toFixed(10)) : 'Error'; };
    $$('[data-k]', root).forEach(b => b.addEventListener('click', () => {
      const k = b.dataset.k;
      if (cur === 'Error' && k !== 'C') { cur = '0'; prev = op = null; }
      if (/\d/.test(k)) { cur = (fresh || cur === '0') ? k : cur + k; fresh = false; }
      else if (k === '.') { if (fresh) { cur = '0.'; fresh = false; } else if (!cur.includes('.')) cur += '.'; }
      else if (k === 'C') { cur = '0'; prev = op = null; fresh = false; }
      else if (k === '⌫') { cur = cur.length > 1 ? cur.slice(0, -1) : '0'; }
      else if (k === '%') { cur = String(+(parseFloat(cur) / 100).toFixed(10)); }
      else if (k === '=') { if (op && prev !== null) { cur = calc(prev, cur, op); op = prev = null; fresh = true; } }
      else { if (op && !fresh) cur = calc(prev, cur, op); prev = cur; op = k; fresh = true; }
      if (cur.length > 14 && cur !== 'Error') cur = String(+parseFloat(cur).toPrecision(10));
      upd();
    }));
  };
  tools.timer = root => {
    root.innerHTML = `<div class="card tool"><div class="bigtime" id="tdisp" role="timer">05:00</div>
      <div class="row"><label class="lbl">Minutes<input id="tmin" type="number" min="0" max="999" value="5" inputmode="numeric"></label><label class="lbl">Seconds<input id="tsec" type="number" min="0" max="59" value="0" inputmode="numeric"></label></div>
      <div class="row"><button class="btn primary" id="tstart">Start</button><button class="btn" id="tpause" disabled>Pause</button><button class="btn ghost" id="treset">Reset</button></div></div>`;
    let left = 0, run = null, endAt = 0;
    const clamp = (v, max) => Math.min(max, Math.max(0, parseInt(v, 10) || 0));
    const read = () => clamp($('#tmin', root).value, 999) * 60 + clamp($('#tsec', root).value, 59);
    const show = s => { $('#tdisp', root).textContent = fmt(s); };
    const stop = () => { clearInterval(run); run = null; $('#tstart', root).disabled = false; $('#tpause', root).disabled = true; };
    $('#tstart', root).onclick = () => {
      if (run) return; if (left <= 0) left = read();
      if (left <= 0) { toast('Enter a time greater than zero.', 'err'); return; }
      endAt = Date.now() + left * 1000; $('#tstart', root).disabled = true; $('#tpause', root).disabled = false;
      run = setInterval(() => {
        left = Math.max(0, Math.ceil((endAt - Date.now()) / 1000)); show(left);
        if (left <= 0) { stop(); beep(880, 0.5); if (navigator.vibrate) navigator.vibrate(300); toast("Time's up! ⏰", 'ok'); }
      }, 200);
    };
    $('#tpause', root).onclick = () => { if (run) { left = Math.max(0, Math.ceil((endAt - Date.now()) / 1000)); stop(); } };
    $('#treset', root).onclick = () => { stop(); left = 0; show(read()); };
    ['#tmin', '#tsec'].forEach(s => $(s, root).addEventListener('input', () => { if (!run) { left = 0; show(read()); } }));
    onCleanup(() => clearInterval(run));
  };
  tools.stopwatch = root => {
    root.innerHTML = `<div class="card tool"><div class="bigtime" id="swd" role="timer">00:00.00</div>
      <div class="row"><button class="btn primary" id="swstart">Start</button><button class="btn" id="swpause" disabled>Pause</button><button class="btn" id="swlap" disabled>Lap</button><button class="btn ghost" id="swreset">Reset</button></div><ol class="laps" id="laps"></ol></div>`;
    let el = 0, t0 = 0, run = null, laps = [];
    const f = ms => { const cs = Math.floor(ms / 10) % 100, s = Math.floor(ms / 1000); return fmt(s) + '.' + String(cs).padStart(2, '0'); };
    const now = () => el + (run ? performance.now() - t0 : 0);
    const upd = () => { $('#swd', root).textContent = f(now()); };
    $('#swstart', root).onclick = () => { if (run) return; t0 = performance.now(); run = setInterval(upd, 40); $('#swstart', root).disabled = true; $('#swpause', root).disabled = false; $('#swlap', root).disabled = false; };
    $('#swpause', root).onclick = () => { if (!run) return; el = now(); clearInterval(run); run = null; upd(); $('#swstart', root).disabled = false; $('#swpause', root).disabled = true; $('#swlap', root).disabled = true; };
    $('#swlap', root).onclick = () => { laps.unshift(f(now())); $('#laps', root).innerHTML = laps.map((l, i) => `<li>Lap ${laps.length - i}: <b>${l}</b></li>`).join(''); };
    $('#swreset', root).onclick = () => { clearInterval(run); run = null; el = 0; laps = []; $('#laps', root).innerHTML = ''; upd(); $('#swstart', root).disabled = false; $('#swpause', root).disabled = true; $('#swlap', root).disabled = true; };
    onCleanup(() => clearInterval(run));
  };
  tools.notes = root => {
    let editing = null;
    const list = () => Store.d.notes;
    function draw() {
      const n = list();
      root.innerHTML = `<div class="card tool"><label class="lbl">Title<input id="ntitle" maxlength="80" placeholder="Note title"></label>
        <label class="lbl">Note<textarea id="nbody" rows="4" maxlength="2000" placeholder="Write something…"></textarea></label>
        <div class="row"><button class="btn primary" id="nsave">${editing ? 'Update note' : 'Add note'}</button>${editing ? '<button class="btn ghost" id="ncancel">Cancel</button>' : ''}</div></div>
        ${n.length ? `<div class="grid">${n.map(x => `<article class="card note"><h3>${esc(x.title)}</h3><p>${esc(x.body).replace(/\n/g, '<br>')}</p><small class="muted">${esc(x.date)}</small><div class="row"><button class="btn sm" data-edit="${x.id}">Edit</button><button class="btn sm danger" data-del="${x.id}">Delete</button></div></article>`).join('')}</div>` : '<div class="empty"><div class="big">📝</div><h3>No notes yet</h3><p>Add your first note above. It is saved on this device.</p></div>'}`;
      if (editing) { const x = n.find(y => y.id === editing); if (x) { $('#ntitle', root).value = x.title; $('#nbody', root).value = x.body; } }
      $('#nsave', root).onclick = () => {
        const title = $('#ntitle', root).value.trim(), body = $('#nbody', root).value.trim();
        if (!title && !body) { toast('Write a title or a note first.', 'err'); return; }
        if (editing) { const x = n.find(y => y.id === editing); if (x) { x.title = title || 'Untitled'; x.body = body; } toast('Note updated', 'ok'); }
        else { n.unshift({ id: 'n' + Date.now(), title: title || 'Untitled', body, date: new Date().toLocaleString() }); toast('Note added', 'ok'); }
        editing = null; Store.save(); if (!Store.ok) toast('Could not save – storage is unavailable.', 'err'); draw();
      };
      const c = $('#ncancel', root); if (c) c.onclick = () => { editing = null; draw(); };
      $$('[data-edit]', root).forEach(b => b.onclick = () => { editing = b.dataset.edit; draw(); window.scrollTo(0, 0); });
      $$('[data-del]', root).forEach(b => b.onclick = () => confirmBox('Delete note?', 'This cannot be undone.', 'Delete', () => { Store.d.notes = list().filter(y => y.id !== b.dataset.del); Store.save(); toast('Note deleted'); draw(); }));
    }
    draw();
  };

  tools.converter = root => {
    const U = { Length: { mm: 0.001, cm: 0.01, m: 1, km: 1000, in: 0.0254, ft: 0.3048, mi: 1609.344 }, Weight: { g: 0.001, kg: 1, lb: 0.45359237, oz: 0.028349523 }, Temperature: { '°C': 1, '°F': 1, K: 1 } };
    root.innerHTML = `<div class="card tool"><label class="lbl">Type<select id="cvt">${Object.keys(U).map(k => `<option>${k}</option>`).join('')}</select></label>
      <label class="lbl">Value<input id="cvv" type="number" inputmode="decimal" value="1" step="any"></label>
      <div class="row2"><label class="lbl">From<select id="cvf"></select></label><label class="lbl">To<select id="cvo"></select></label></div>
      <div class="bigtime" id="cvr" role="status">—</div></div>`;
    const t = $('#cvt', root), f = $('#cvf', root), o = $('#cvo', root), v = $('#cvv', root), r = $('#cvr', root);
    const fill = () => { const k = Object.keys(U[t.value]); f.innerHTML = k.map(x => `<option>${x}</option>`).join(''); o.innerHTML = f.innerHTML; o.selectedIndex = Math.min(1, k.length - 1); calc(); };
    const calc = () => {
      const n = parseFloat(v.value); if (!isFinite(n)) { r.textContent = 'Enter a number'; return; }
      let out;
      if (t.value === 'Temperature') { const c = f.value === '°C' ? n : f.value === '°F' ? (n - 32) * 5 / 9 : n - 273.15; out = o.value === '°C' ? c : o.value === '°F' ? c * 9 / 5 + 32 : c + 273.15; }
      else out = n * U[t.value][f.value] / U[t.value][o.value];
      r.textContent = String(+out.toFixed(6)) + ' ' + o.value;
    };
    [f, o, v].forEach(e => e.addEventListener('input', calc)); t.addEventListener('change', fill); fill();
  };

  /* ---------- XP and streak ---------- */
  function award(key, xp) {
    const d = Store.d; if (d.awarded.includes(key)) return;
    d.awarded.push(key); const lv = Math.floor(d.xp / 100); d.xp += xp; Store.save();
    toast('+' + xp + ' XP', 'ok');
    if (Math.floor(d.xp / 100) > lv) toast('Level up! You are level ' + (Math.floor(d.xp / 100) + 1) + ' 🚀', 'ok');
  }
  function streakTick() {
    const d = Store.d, f = t => t.toLocaleDateString('en-CA'), today = f(new Date()), y = f(new Date(Date.now() - 864e5));
    if (d.streak.last === today) return;
    d.streak.count = d.streak.last === y ? d.streak.count + 1 : 1; d.streak.last = today; Store.save();
  }

  return { $, $$, esc, go, fmt, shuffle, onCleanup, cleanup, Store, toast, beep, modal, closeModal, confirmBox, startQuiz, tools, award, streakTick };
})();
